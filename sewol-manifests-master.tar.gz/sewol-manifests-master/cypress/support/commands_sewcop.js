/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

// Login and select role that is passed in
Cypress.Commands.add("sewcopSelectRole", (role) => {
    cy.login('Xavier').then(() => {
      cy.visit({
        url: '/',
        failOnStatusCode: false
      });

      // Select the role from the RTiles display
      cy.get('#role-select-modal-prompt-option').select(`${role}`);
      cy.get('#role-select-modal-submit').click();
    });
});

// Opens tile with tilename being passed in (assuming we are opening and closing one tile at a time)
Cypress.Commands.add("sewcopAddTile", (tileName) => {
    switch(tileName.toLowerCase()) {
      case "proposedschedule":
        cy.get('.mdi-developer-board').trigger('mouseover');
        cy.get('#dragtile-proposed-schedule-timeline-tile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-proposed-schedule-timeline-tile > .info-border').trigger('mouseup', {force:true});

        // Wait for the tile tabs to be loaded on the screen to verify the tile is visible.
        cy.get("#theLayoutContainer").find("div.timeline-mode-selection-container").should('be.visible');
        break;
      case "executionschedule":
        cy.get('.mdi-developer-board').trigger('mouseover');
        cy.get('#dragtile-execution-schedule-timeline-tile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-execution-schedule-timeline-tile > .info-border').trigger('mouseup', {force:true});

        // Wait for the tile tabs to be loaded on the screen to verify the tile is visible.
        cy.get("#theLayoutContainer").find("div.timeline-mode-selection-container").should('be.visible');
        break;
      case "missionfolders":
        cy.get('.mdi-developer-board').trigger('mouseover');
        cy.get('#dragtile-case-folder-tile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-case-folder-tile > .info-border').trigger('mouseup', {force:true});

        // Wait for the tile tabs to be loaded on the screen to verify the tile is visible.
        cy.get("#theLayoutContainer").find("div.casefolder-container").should('be.visible');
        break;
      case "tacc2gui":
        cy.get('.mdi-developer-board').trigger('mouseover');
        cy.get('#dragtile-TacC2UiTile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-TacC2UiTile > .info-border').trigger('mouseup', {force:true});

        // Wait for the tile tabs to be loaded on the screen to verify the tile is visible.
        cy.get("#theLayoutContainer").find("div.rTileContainer").should('be.visible');
        break;
      case "awedisplay":
        cy.get('.mdi-developer-board').trigger('mouseover');
        cy.get('#dragtile-awe-display-tile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-awe-display-tile > .info-border').trigger('mouseup', {force:true});

        // Wait for the tile tabs to be loaded on the screen to verify the tile is visible.
        cy.get("#theLayoutContainer").find("div.lm_item_container").should('be.visible');
        break;
      default:
        throw new Error('Invalid parameter: tile name is not one of the following: proposedschedule, executionschedule, missionfolders, tacc2gui, awedisplay');
    }
});

// Close tile (will only function as expected if one tile is open at a time)
Cypress.Commands.add("sewcopCloseTile", () => {
    cy.get("#theLayoutContainer").find("li.lm_close").click();
});