/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

export default class TargetData {

    // a unique cypress alias for the json representation of this MissionPlan
    #json;

    // Signal identifier within this target package.
    #soiDesignator;

    // Optional construction fields.
    #optional;

    constructor(soiDesignator, optional = {}) {
        this.#soiDesignator = soiDesignator;
        this.#optional = structuredClone(optional);

        this.#json = TargetData.getJsonAlias(this);

        // Create TargetData json.
        cy.fixture('sewcop/model/TargetData').then((targetDataJson) => {
            let targetDataCopy = structuredClone(targetDataJson);
            cy.wrap(targetDataCopy).as(this.#json).then(targetDataJson => {
                this.#formatJson(targetDataJson);
            });
        });
    }

    getSoiDesignator() {
        return this.#soiDesignator;
    }

    getOptional() {
        return structuredClone(this.#optional);
    }

    updateOptional(updates) {
        let optionalCopy = structuredClone(this.#optional);
        updates(optionalCopy);
        this.#optional = optionalCopy;
        cy.get(`@${this.#json}`).then(targetDataJson => {
            this.#formatJson(targetDataJson);
        });
    }

    createRemote() {
        cy.get(`@${this.#json}`).then(targetDataJson => {
            cy.request({
                method: 'POST',
                url: '/repository/targetData',
                body: targetDataJson
            })
        });
    }

    #formatJson(targetDataJson) {
        targetDataJson.soiDesignator = this.#soiDesignator;
        targetDataJson.targetAssociations = (this.#optional.targetAssociations != null) ? this.#optional.targetAssociations : ((targetDataJson.targetAssociations != null) ? targetDataJson.targetAssociations : [crypto.randomUUID()]);
        targetDataJson.timestamp = (this.#optional.timestamp != null) ? this.#optional.timestamp : TargetData.#getIsoTimeString(Date.now());
        targetDataJson.idStatus = (this.#optional.idStatus != null) ? this.#optional.idStatus : "Meets ID Criteria";
        targetDataJson.priorityValue = (this.#optional.priorityValue != null) ? this.#optional.priorityValue : 20;
        targetDataJson.priorityLevel = (this.#optional.priorityLevel != null) ? this.#optional.priorityLevel : "H";
        targetDataJson.backupDesignator = (this.#optional.backupDesignator != null) ? this.#optional.backupDesignator : null;
        targetDataJson.uplink = (this.#optional.uplink != null) ? this.#optional.uplink : {
            "satellite": "45026",
            "satAssociation": "Commercial Company",
            "satBeamId": "",
            "satAperture": "",
            "satTransponder": "",
            "satModemType": "",
            "polarization": "Horizontal",
            "centerFrequency": 13000.000000,
            "signalConfidence": "Actual",
            "persistence": "Continuous",
            "bandwidth": 5.000000,
            "modulation": "BPSK",
            "symbolRate": 1.000000,
            "fec": "3/4",
            "channelId": "",
            "maxJsr": "",
            "eirp": ""
        };
        targetDataJson.downlink = (this.#optional.downlink != null) ? this.#optional.downlink : {
            "satellite": "28659",
            "satAssocation": "Commercial Company",
            "satBeamId": "",
            "satAperture": "",
            "satTransponder": "",
            "satModemType": "",
            "polarization": "Vertical",
            "centerFrequency": 15000.000000,
            "signalConfidence": "Actual",
            "persistence": "Continuous",
            "bandwidth": 4.000000,
            "modulation": "PWM",
            "symbolRate": 3.000000,
            "fec": "5/6",
            "channelId": ""
        };
    }

    static getJsonAlias(targetData) {
        if (targetData instanceof TargetData) {
            return "TargetData_" + targetData.getSoiDesignator();
        } else {
            return "TargetData_" + targetData;
        }
    }

    /**
     * convert numberic timestamp to ISO 8601 formatted string.
     * @param {number} timestamp the timestamp to be converted, in milis-since-epoch format.
     * @returns the ISO 8601 formatted string for the timestamp
     */
    static #getIsoTimeString(timestamp) {
        let myDate = new Date();
        myDate.setTime(timestamp);
        return myDate.toISOString();
    }
}