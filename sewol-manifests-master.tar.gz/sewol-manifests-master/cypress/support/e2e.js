/***********************************************************************************************************************
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import './commands'
import './commands_rmt_sim'
import './commands_sewcop'

/*
Cypress.on('uncaught:exception', (err, runnable) => {
    // returning false here prevents Cypress from
    // failing the test
    return false
  })
*/

// Start the reverse proxy and point the baseUrl to it
before(() => {
  cy.task("startReverseProxy");

  const proxyUrl = Cypress.env("proxyUrl");
  Cypress.config("baseUrl", proxyUrl);
})
