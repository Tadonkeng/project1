/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

const { Given, When, Then, Step } = require("@badeball/cypress-cucumber-preprocessor");
import * as timeConverter from "../../../fixtures/common/timeConverter.js";
import SystemReset from "../../../fixtures/common/systemReset.js";

var uploadedMtos = [];
var mtoTasks = [];

function replaceAllInJson(json,findString,replaceString) {
    let jsonString = JSON.stringify(json)
    jsonString = jsonString.replaceAll(findString,replaceString);
    return JSON.parse(jsonString)
}

Given("all RMTs have been deleted from the RMT simulator", () => {
    cy.resetRmtSim();
});

Given("all RMTs, Tasks, Targets, and MTOs have been deleted from the Repository", () => {
    SystemReset.resetRepository();
});

Given("the RMT simulator sends a {word} event for {word} {}in {int} second(s)", function (eventType, rmtId, optionalCaveat, delay) {
    cy.fixture('seit/rmt/' + eventType).then((eventMessage) => {
        const rmtNum = rmtId.substring(4);
        eventMessage = replaceAllInJson(eventMessage,'RMTID',rmtId);
        eventMessage = replaceAllInJson(eventMessage,'RMTNUM',rmtNum);
        cy.log(JSON.stringify(eventMessage))
        if (eventType == 'StartUpEvent') {
            cy.fixture('seit/rmt/rmtLocations').then((rmtLocations) => {
                eventMessage.capabilities.location = rmtLocations[rmtId]
            })
        } else if (eventType == 'TransmitStateEvent') {
           if (optionalCaveat == 'with transmitting true ') {
               eventMessage = replaceAllInJson(eventMessage,'false','true');
           }         
        } else if (eventType == 'MissionReportEvent') {
            let simTime = new Date(Date.now() + (delay * 1000));
            eventMessage.mission_report[0].event_details.timestamp = simTime.toISOString();
        }

        cy.coiRmtSimEvent({
            "eventType": eventType,
            "rmtId": rmtId,
            "message": eventMessage,
            "delay": delay
        });
    });
    cy.wait(1000);
});

Given("the RMT simulator sends a periodic {word} event for {word} every {int} second(s)", function (eventType, rmtId, periodicity) {
    cy.fixture('seit/rmt/' + eventType).then((eventMessage) => {
        const rmtNum = rmtId.substring(4);
        let eventMessageString = JSON.stringify(eventMessage)
        eventMessageString = eventMessageString.replaceAll('RMTID',rmtId);
        eventMessageString = eventMessageString.replaceAll('RMTNUM',rmtNum);
        eventMessage = JSON.parse(eventMessageString)
        cy.coiRmtSimEvent({
            "eventType": eventType,
            "rmtId": rmtId,
            "message": eventMessage,
            "delay": 1,
            "periodInSeconds": periodicity,
            "timestampSubstitutionToken": "TOBEREPLACED"
        });
    });
    cy.wait(1000)
});

Given("the RMT simulator has been configured for {word}", function (rmtId) {
    cy.coiRmtSimAdd(rmtId);
    cy.coiRmtSimStart(rmtId);
    cy.wait(1000);
    Step(this, `the RMT simulator sends a StartUpEvent event for ${rmtId} in 1 second`)
    rmtSimulatorNominalPeriodicEvents = [
        'HealthAndStatus',
        'HeartbeatEvent',
        'BITResultsEvent',
        'AntennaStatusEvent',
        'ReceiverTuneEvent',
    ]
    for (let periodicEventType of rmtSimulatorNominalPeriodicEvents) {
        Step(this, `the RMT simulator sends a periodic ${periodicEventType} event for ${rmtId} every 10 seconds`)
    }
});

Given("the RMT simulator is configured to respond to a {word} for {word}", function (requestType, rmtId) {
    cy.fixture('seit/rmt/' + requestType).then((requestMessage) => {
        const rmtNum = rmtId.substring(4);
        let requestMessageString = JSON.stringify(requestMessage)
        requestMessageString = requestMessageString.replaceAll('RMTID',rmtId);
        requestMessageString = requestMessageString.replaceAll('RMTNUM',rmtNum);
        requestMessage = JSON.parse(requestMessageString)
        cy.coiRmtSimRequestResponseCommand(requestMessage);
    });
});

Given("{string} has been loaded", function(targetData) {
    const targetDataFile = targetData.replaceAll(" ", "_").toLowerCase()
    const rbacUser = 'Oprah'
    cy.login(rbacUser)
    cy.fixture(`seit/${targetDataFile}.json`).then((targetData) => {
        for (let targetDatum of targetData) {
            cy.request({
                method: 'POST',
                url: 'repository/sewol/targetData',
                body: targetDatum
            });
        }
    });
    cy.logout(rbacUser)
    cy.wait(1000)
});

When("a Operational Planner loads a(n) {string} containing target(s) {word} with a {int} minute duration starting {int} minute(s) in the future", function (mtoName, targetSignalsList, duration, delayMin) {
    const mtoFile = mtoName.replaceAll(" ", "_").toLowerCase()
    const rbacUser = 'Oprah'
    cy.login(rbacUser)
    cy.fixture(`seit/${mtoFile}.json`).then((mto) => {
        // Unique MTO ID
        mto.number = Math.floor(Math.random() * 10000)
        
        // Update MTO timestamps for near future
        let mtoTimestamp = Math.ceil(Date.now() / (1000 * 60.0)) * 60 * 1000 // Round to the nearest future minute
        let mtoStart = mtoTimestamp + (delayMin * 60 * 1000)
        let mtoEnd = mtoStart + (duration * 60 * 1000)
        mto['timestamp'] = timeConverter.convertToMtoTime(mtoTimestamp)
        mto['periodStart'] = timeConverter.convertToMtoTime(mtoStart)
        mto['periodEnd'] = timeConverter.convertToMtoTime(mtoEnd)

        // Remove mission targets from MTO unless they match
        var newMissionTargets = []
        const targetSignals = targetSignalsList.split(',')
        for (let missionTarget of mto['missionTargets']) {
            if (targetSignals.includes(missionTarget.jiptlId)) {
                newMissionTargets.push(missionTarget)
            }
        }
        mto['missionTargets'] = newMissionTargets

        uploadedMtos.push(mto) // Set MTO state to allow for MTO re-use in later steps
        cy.request({
            method: 'POST',
            url: 'repository/sewol/missionTypeOrder',
            body: mto
        });
    });
    cy.logout(rbacUser)
    cy.wait(1000)
});

When("a Operational Planner loads a(n) {string} containing the following targets", function (mtoName, table) {
    // | Signal | EffectStart        | EffectStop       |
    // | SOI1   | <Relative # mins>  | <Relative # mins | 
    // | SOI2   | 10 | 70 |
    
    const mtoFile = mtoName.replaceAll(" ", "_").toLowerCase()
    const rbacUser = 'Oprah'
    cy.login(rbacUser)
    cy.fixture(`seit/${mtoFile}.json`).then((mto) => {
        // Unique MTO ID
        mto.number = Math.floor(Math.random() * 10000)
        
        // Update MTO timestamps for near future
        let mtoTimestamp = Date.now()
        let mtoStart = mtoTimestamp + (14 * 24 * 60 * 1000)
        let mtoEnd = mtoTimestamp
        for (target of table.hashes()) {
            mtoStart = Math.min(mtoStart, mtoTimestamp + (parseInt(target.EffectStart) * 60 * 1000))
            mtoEnd = Math.max(mtoEnd, mtoTimestamp + (parseInt(target.EffectStop) * 60 * 1000))
        }
        mto['timestamp'] = timeConverter.convertToMtoTime(mtoTimestamp)
        mto['periodStart'] = timeConverter.convertToMtoTime(mtoStart)
        mto['periodEnd'] = timeConverter.convertToMtoTime(mtoEnd)

        // Remove mission targets from MTO unless they match
        var newMissionTargets = []
        for (let missionTarget of mto['missionTargets']) {
            for (target of table.hashes()) {
                if (target.Signal == missionTarget.jiptlId) {
                    missionTarget['startTimeOfEffect'] = timeConverter.convertToMtoTime(mtoTimestamp + (parseInt(target.EffectStart) * 60 * 1000))
                    missionTarget['stopTimeOfEffect'] = timeConverter.convertToMtoTime(mtoTimestamp + (parseInt(target.EffectStop) * 60 * 1000))
                    newMissionTargets.push(missionTarget)
                }
            }
        }
        mto['missionTargets'] = newMissionTargets

        uploadedMtos.push(mto) // Set MTO state to allow for MTO re-use in later steps
        cy.request({
            method: 'POST',
            url: 'repository/sewol/missionTypeOrder',
            body: mto
        });
    });
    cy.logout(rbacUser)
    cy.wait(1000)
});

When("a Operational Planner updates the MTO to remove target {word}", function (targetToRemove) {
    const rbacUser = 'Oprah'
    cy.login(rbacUser)
    for (let i = 0; i < uploadedMtos[uploadedMtos.length - 1].missionTargets.length; i++) {
        if (uploadedMtos[uploadedMtos.length - 1].missionTargets[i].jiptlId == targetToRemove) {
            uploadedMtos[uploadedMtos.length - 1].missionTargets.splice(i, 1)
        }
    }
    cy.request({
        method: 'POST',
        url: 'repository/sewol/missionTypeOrder',
        body: mto
    });
    cy.logout(rbacUser)
    cy.wait(1000)
});

When("the RMT simulator sends a {word} event for {word} at MTO start", function (eventType, rmtId) {
    delay = Math.round((timeConverter.convertMtoTimeToMillis(uploadedMtos[uploadedMtos.length - 1].periodStart) - Date.now()) / 1000)
    Step(this, `the RMT simulator sends a ${eventType} event for ${rmtId} in ${delay} seconds`)
});

When("the RMT simulator sends a {word} event for {word} at MTO end", function (eventType, rmtId) {
    delay = Math.round((timeConverter.convertMtoTimeToMillis(uploadedMtos[uploadedMtos.length - 1].periodEnd) - Date.now()) / 1000)
    Step(this, `the RMT simulator sends a ${eventType} event for ${rmtId} in ${delay} seconds`)
});

When("we wait {int} second(s)", function (delay) {
    cy.wait(delay * 1000)
});

When("the MTO ends", () => {
    cy.wait(Math.round(timeConverter.convertMtoTimeToMillis(uploadedMtos[uploadedMtos.length - 1].periodEnd) - Date.now()))
});

When("the Proposed Schedule is approved", () => {
    const rbacUser = 'Mike'
    cy.login(rbacUser)
    cy.request({
        method: 'POST',
        url: 'data-service/sewol/missionPlan/setState',
        body: {
            "number": uploadedMtos[uploadedMtos.length - 1].number,
            "isApproved": true
        }
    });
    cy.logout(rbacUser)
    cy.wait(1000)
});

When("the RMT simulator sends Tasking Events for the MTO tasks", () => {
    for (var mtoTask of mtoTasks) {
        const taskStart = Math.round((Date.parse(mtoTask.startTime) - Date.now()) / 1000)
        Step(this, `the RMT simulator sends a TaskingStartedEvent event for ${mtoTask.sewSystemName} in ${taskStart} seconds`)
        const taskEnd = Math.round((Date.parse(mtoTask.endTime) - Date.now()) / 1000)
        Step(this, `the RMT simulator sends a TaskingEndedEvent event for ${mtoTask.sewSystemName} in ${taskEnd} seconds`)
        if (mtoTask.taskType == "ES_EA") {
            Step(this, `the RMT simulator sends a TransmitStateEvent event for ${mtoTask.sewSystemName} with transmitting true in ${taskStart} seconds`)  
            Step(this, `the RMT simulator sends a TransmitStateEvent event for ${mtoTask.sewSystemName} with transmitting false in ${taskEnd} seconds`) 
            Step(this, `the RMT simulator sends a MissionReportEvent event for ${mtoTask.sewSystemName} for tasking group ${mtoTask.taskingGroupId} in ${taskEnd} seconds`) 
        }
    }
});

When("the RMT simulator sets the conditional EA task to active {int} minutes(s) after MTO start", function (delay) {
    for (var mtoTask of mtoTasks) {
        if (mtoTask.taskType == "ES_EA") {
            const delay = Math.round((timeConverter.convertMtoTimeToMillis(uploadedMtos[uploadedMtos.length - 1].periodStart) + (delay * 60 * 1000) - Date.now()) / 1000)
            const taskEnd = Math.round((Date.parse(mtoTask.endTime) - Date.now()) / 1000)
            Step(this, `the RMT simulator sends a MissionStateChangeEvent event for ${mtoTask.sewSystemName} for tasking group ${mtoTask.taskingGroupId} in ${delay} seconds`)
            Step(this, `the RMT simulator sends a MissionTriggerEvent event for ${mtoTask.sewSystemName} for tasking group ${mtoTask.taskingGroupId} in ${delay} seconds`)   
            Step(this, `the RMT simulator sends a TransmitStateEvent event for ${mtoTask.sewSystemName} with transmitting true in ${delay} seconds`)  
            Step(this, `the RMT simulator sends a TransmitStateEvent event for ${mtoTask.sewSystemName} with transmitting false in ${taskEnd} seconds`) 
            Step(this, `the RMT simulator sends a MissionReportEvent event for ${mtoTask.sewSystemName} for tasking group ${mtoTask.taskingGroupId} in ${taskEnd} seconds`) 
        }
    }
});

Then("a proposed schedule is generated containing {int} task(s) for an RMT system", function (expectedNewTasks) {
    cy.wait(10000) // Wait for Tac C2 to generate schedule
    const rbacUser = 'Oprah'
    cy.login(rbacUser)
    cy.request({
        method: 'GET',
        url: 'data-service/sewTask'
    }).then((resp) => {
        expect(resp.status).to.equals(200)
        var newTasks = 0;
        for (var i = 0; i < resp.body.length; i++) {
            for (uploadedMto of uploadedMtos) {
                if (resp.body[i].missionNumber == uploadedMto.number) {
                    newTasks++
                    mtoTasks.push(resp.body[i])
                }
            }
        }
        expect(newTasks).to.equals(expectedNewTasks)
    })
    cy.logout(rbacUser)
});

Then("all MTO tasks have the state {word}", function (taskState) {
    cy.wait(10000) // Wait for RMT/COI/Repository to update task state
    const rbacUser = 'Mike'
    cy.login(rbacUser)
    cy.request({
        method: 'GET',
        url: 'data-service/sewTask'
    }).then((resp) => {
        expect(resp.status).to.equals(200)
        for (mtoTask of mtoTasks) {
            for (var i = 0; i < resp.body.length; i++) {
                if (mtoTask.taskingGroupId == resp.body[i].taskingGroupId && mtoTask.taskName == resp.body[i].taskName ) {
                    expect(resp.body[i].execStatus.execState).to.equal(taskState)
                }
            }
        }
    })
    cy.logout(rbacUser)
});

Then("SEWCOP is accessible", () => {
    cy.login('Sean')
    cy.visit('rtiles/')
    cy.logout('Sean')
});
