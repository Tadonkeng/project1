/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

function replaceAllInJson(json,findString,replaceString) {
    let jsonString = JSON.stringify(json)
    jsonString = jsonString.replaceAll(findString,replaceString);
    return JSON.parse(jsonString)
}
    
// Add RMT
Cypress.Commands.add("coiRmtSimAdd", (rmtId) => {
    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: `/coi-rmt-simulator/rmt/add`,
            body: {
                "rmtId": rmtId
            }
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// Start RMT
Cypress.Commands.add("coiRmtSimStart", (rmtId) => {
    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: `/coi-rmt-simulator/rmt/start`,
            body: {
                "rmtId": rmtId
            }
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
        cy.request({
            method: "GET",
            url: `/coi-rmt-simulator/rmt/listAll`,
        }).then((resp) => {
            expect(resp.body).to.include.all.keys(rmtId)
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// Delete RMT
Cypress.Commands.add("coiRmtSimDelete", (rmtId) => {
    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: `/coi-rmt-simulator/rmt/delete`,
            body: {
                "rmtId": rmtId
            }
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// Stop all RMTs
Cypress.Commands.add("coiRmtSimStopAll", () => {
    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: `/coi-rmt-simulator/rmt/stopAll`,
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// Delete all RMTs
Cypress.Commands.add("coiRmtSimDeleteAll", () => {
    cy.login('Travis').then(() => {
        cy.request({
            method: "DELETE",
            url: `/coi-rmt-simulator/event/`,
        }).then((resp) => {
            expect(resp.status).to.equals(200);
            expect(JSON.stringify(resp.body)).to.have.string('Successfully cleared events');
        });
        cy.request({
            method: "DELETE",
            url: `/coi-rmt-simulator/command/`,
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
        cy.request({
            method: "POST",
            url: `/coi-rmt-simulator/rmt/deleteAll`,
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
        cy.request({
            method: "GET",
            url: `/coi-rmt-simulator/rmt/listAllDetailed`,
        }).then((resp) => {
            expect(resp.body).to.be.empty;
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// SEND EVENT
Cypress.Commands.add("coiRmtSimEvent", (eventBody) => {
    // Example: coiRmtSimEvent{"eventType":"HeartbeatEvent","rmtId":"RMT-101","message":JSONmessage,"delay":5}
    // Example: coiRmtSimEvent{"eventType":"HeartbeatEvent","rmtId":"RMT-101","message":JSONmessage,"delay":5,"periodInSeconds":10}
    rmtSimEvent = eventBody

    var endpoint = 'coi-rmt-simulator/event/'
    if ('periodInSeconds' in eventBody) {
        endpoint = 'coi-rmt-simulator/event/periodic/'
    }

    // Update request timestamps using the delay provided
    let simTime = new Date(Date.now() + (eventBody.delay * 1000));
    if (('timestamp' in rmtSimEvent.message) && (!('periodInSeconds' in eventBody))) {
        rmtSimEvent.message.timestamp = simTime.toISOString();
    }
    rmtSimEvent.simulationTime = simTime.toISOString();
    delete rmtSimEvent.delay

    // Convert the message to an escaped string
    let messageString = JSON.stringify(rmtSimEvent.message);
    rmtSimEvent.message = messageString

    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: endpoint,
            body: rmtSimEvent,
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// Sending Request Response Command from coi-rmt-simulator
Cypress.Commands.add("coiRmtSimRequestResponseCommand", (commandBody) => {
    let messageBodyString = JSON.stringify(commandBody.response.messageBody);
    commandBody.response.messageBody = messageBodyString

    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: `/coi-rmt-simulator/command/`,
            body: commandBody
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// testcapabilitiesReponse from coi-rmt-communication
Cypress.Commands.add("coiRmtSimtestcapabilitiesResponse", (testcapabilitiesResponseBody) => {
    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: `/coi-rmt-communication/test/capabilitiesResponse`,
            body: testcapabilitiesResponseBody
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

// scheduledTaskingRequest from coi-rmt-processing
Cypress.Commands.add("coiRmtSimScheduledTaskingRequest", (ScheduledTaskingRequestBody) => {
    cy.login('Travis').then(() => {
        cy.request({
            method: "POST",
            url: `/coi-rmt-processing/test/scheduledTaskingRequest`,
            body: ScheduledTaskingRequestBody
        }).then((resp) => {
            expect(resp.status).to.equals(200);
        });
    }).then(() => {
        cy.logout('Travis');
    })
});

Cypress.Commands.add("resetRmtSim", () => {
    cy.coiRmtSimStopAll();
    cy.wait(1000);
    cy.coiRmtSimDeleteAll();
    cy.wait(10000);
});

// Send the StartUpEvent message for an RMT
Cypress.Commands.add("coiRmtSimStartUpEvent", (rmtId) => {
    cy.fixture('seit/rmt/StartUpEvent').then((startupEventMessage) => {
        const rmtNum = rmtId.substring(4);
        startupEventMessage = replaceAllInJson(startupEventMessage,'RMTID',rmtId);
        startupEventMessage = replaceAllInJson(startupEventMessage,'RMTNUM',rmtNum);
        cy.fixture('seit/rmt/rmtLocations').then((rmtLocations) => {
            startupEventMessage.capabilities.location = (rmtLocations[rmtId] != null) ? rmtLocations[rmtId] : rmtLocations["RMT-9"];
        })
        cy.coiRmtSimEvent({
            "eventType": "StartUpEvent",
            "rmtId": rmtId,
            "message": startupEventMessage,
            "delay": 5
        });
    });
});