/***********************************************************************************************************************
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import Env from '../fixtures/common/env.cjs';

Cypress.Commands.add("login", (userid, role = null) => {
    cy.setUser(userid)
    cy.setRole(userid, role)
});

Cypress.Commands.add("loginWithoutRole", (userid) => {
    cy.setUser(userid)
    cy.unsetRole(userid)
});

Cypress.Commands.add("logout", (userid) => { 
    cy.unsetRole(userid)
    cy.unsetUser()
});

Cypress.Commands.add("setUser", (userid) => { 
    // Only set the user if a user ID was not specified in the environment.
    // A user ID in the environment implies we are running in a local mode
    // and the user is fixed as the human running the test.
    if (Cypress.env('userId') === undefined) {  
        cy.task("setUser", userid)
    }
});

Cypress.Commands.add("unsetUser", () => { 
    // Only unset the user if a user ID was not specified in the environment.
    // A user ID in the environment implies we are running in a local mode
    // and the user is fixed as the human running the test.
    if (Cypress.env('userId') === undefined) {  
        cy.task("unsetUser")
    }
});

Cypress.Commands.add("setRole", (userid, role = null) => {

    // If a user ID was specified in the environment, that overrides what was
    // passed in.
    selectedUserId = Cypress.env('userId') ? Env.expand(Cypress.env('userId')) : userid 

    cy.fixture('common/casl_data').then((caslData) => {
        // If a null role was passed in, then lookup the current role
        // in casl_data.json (this lookup is based on the passed in user ID)
        let selectedRole = role ? role : caslData.users[userid].current_role 

        if (selectedRole == null) {
            // If there is no role, unset it instead
            cy.unsetRole(selectedUserId)
        } else {
            // Make call to set current role for userid in current role service
            let path = "/data-service/admin/set-current-role"
            let params = "?userId=" + selectedUserId + "&role=" + selectedRole
            cy.request({
                method: 'PUT',
                url: Cypress.config('baseUrl') + path + params,
                failOnStatusCode: false
            }).then((response) => {
                expect(response.status).to.eq(200)
            })
        }
    });   

});

Cypress.Commands.add("unsetRole", (userid) => { 
    // If a user ID was specified in the environment, that overrides what was
    // passed in.
    selectedUserId = Cypress.env('userId') ? Env.expand(Cypress.env('userId')) : userid 

    // Make call to unset current role for userid in current role service
    let path = "/data-service/admin/delete-current-role"
    let params = "?userId=" + selectedUserId
    cy.request({
        method: 'DELETE',
        url: Cypress.config('baseUrl') + path + params,
        failOnStatusCode: false
    }).then((response) => {
        expect(response.status).to.eq(200)
    })
});
