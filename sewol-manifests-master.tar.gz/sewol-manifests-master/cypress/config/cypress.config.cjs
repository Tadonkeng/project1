/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

const { defineConfig } = require("cypress");
const createBundler = require("@bahmutov/cypress-esbuild-preprocessor");
const { addCucumberPreprocessorPlugin } = require("@badeball/cypress-cucumber-preprocessor");
const { createEsbuildPlugin } = require("@badeball/cypress-cucumber-preprocessor/esbuild");
const ReverseProxy = require('../fixtures/common/reverse_proxy.cjs')
const Env = require("../fixtures/common/env.cjs");

async function setupNodeEvents(on, config) {
  // Cypress won't allow muliple listeners (possible defect), so we use
  // the cypress-on-fix as a workaround.
  const multiOn = require('cypress-on-fix')(on)

  // This is required for the preprocessor to be able to generate JSON reports after each run, and more,
  await addCucumberPreprocessorPlugin(multiOn, config);

  multiOn(
    "file:preprocessor",
    createBundler({
      plugins: [createEsbuildPlugin(config)],
    })
  );

  // If a userId is specified, perform system environment variable expansion on it
  if (config.env.userId) {
     config.env.userId = Env.expand(config.env.userId)
  } 

  multiOn("task", {
    log: (message) => {
      console.log(message);
      return null;
    },
    setUser: (userid) => {
      ReverseProxy.setUser(userid);
      return null;
    },
    unsetUser: () => {
      ReverseProxy.unsetUser();
      return null;
    },
    startReverseProxy: () => {
      const proxyUrl = new URL(Env.expand(config.env.proxyUrl));
      let proxyPort = proxyUrl.port;
      if (!proxyPort) {
         proxyPort = "80"
      }

      const stagingUrl = Env.expand(config.env.stagingUrl)

      let sessionCookie = null
      if (config.env.sessionCookie) {
        sessionCookie = Env.expand(config.env.sessionCookie)
      }

      routerTable = {}
      pathRewriteTable = new Map()

      ReverseProxy.stop();
      ReverseProxy.start(proxyPort, stagingUrl, sessionCookie, routerTable, pathRewriteTable);

      return null;
    },
    stopReverseProxy: () => {
      ReverseProxy.stop();
      return null;
    },
  });

  // Make sure to return the config object as it might have been modified by the plugin.
  return config;
}

module.exports = defineConfig({
  //change to true for video artifacts to be created
  video: false,
  reporter: 'junit',
  reporterOptions:{
    mochaFile: 'test-results-[hash].xml',
  },
  e2e: {
    specPattern: '**/*.{feature,cy.js}',
    excludeSpecPattern: [
      '**/coiRBAC.cy.js', //SEWOL-6495
      '**/sewSystemCapabilities.cy.js', //SEWOL-5799
      '**/approve.cy.js', //SEWOL-5795
      '**/mto.cy.js', //SEWOL-5845
      '**/roles.cy.js', //SEWOL-5812
      '**/targetdatainfo.cy.js' //SEWOL-6494
    ],
    // default 4 second timeout is too short for SEWCOP
    defaultCommandTimeout: 20000,
    Browser: {
      chromeWebSecurity: false,
    },
    setupNodeEvents,
  },
});
