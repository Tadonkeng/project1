/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

export default class MainMethods {
    //Generic API call wrapper
    static ApiCall(url, method, body) {
        cy.request({
            method: method,
            url: url,
            body: body,
            failOnStatusCode: false,
        }).as('details')
    }

    //Post-Get call wrapper for multi-part data
    //We are posting, then getting,
    //Assumes multiple bits of info being passed

    static PostGet(body, post_url, get_url) {
        cy.request({
            method: 'POST',
            url: post_url,
            body: body,
            failOnStatusCode: false,
        })
            .as('post_details')
            .then((response) => {
                let id = response.body[0]['id']
                expect(response.status).to.eq(200)
                cy.request({
                    method: 'GET',
                    url: get_url + id,
                    failOnStatusCode: false,
                })
                    .as('get_details')
                    .then((response) => {
                        expect(response.status).to.eq(200)
                    })
            })
    }

    //PutGet call wrapper
    //Passing in put_params and get_params
    static PutGet(body, put_url, get_url, put_params, get_params) {
        cy.request({
            method: 'PUT',
            url: put_url + put_params,
            body: body,
            failOnStatusCode: false,
        })
            .as('put_details')
            .then((response) => {
                expect(response.status).to.eq(200)
                cy.request({
                    method: 'GET',
                    url: get_url + get_params,
                    failOnStatusCode: false,
                })
                    .as('get_details')
                    .then((response) => {
                        expect(response.status).to.eq(200)
                    })
            })
    }
    //PutGetDelete call wrapper
    //Passing in url's with put_params, get_params and delete_params
    static PutGetDelete(
        body,
        put_url,
        get_url,
        delete_url,
        put_params,
        get_params,
        delete_params
    ) {
        cy.request({
            method: 'PUT',
            url: put_url + put_params,
            body: body,
            failOnStatusCode: false,
        })
            .as('put_details')
            .then((response) => {
                expect(response.status).to.eq(200)
                cy.request({
                    method: 'GET',
                    url: get_url + get_params,
                    failOnStatusCode: false,
                })
                    .as('get_details')
                    .then((response) => {
                        expect(response.status).to.eq(200)
                        cy.request({
                            method: 'DELETE',
                            url: delete_url + delete_params,
                            failOnStatusCode: false,
                        })
                            .as('delete_details')
                            .then((response) => {
                                expect(response.status).to.eq(200)
                            })
                    })
            })
    }
    //Post-Get-Put-Delete call wrapper
    //We are posting, then getting and verifying, then deleting
    //Assumption is that we get an id back to get and delete on

    static PostGetPutDelete(
        body,
        put_body,
        post_url,
        get_url,
        put_url,
        delete_url
    ) {
        cy.request({
            method: 'POST',
            url: post_url,
            body: body,
            failOnStatusCode: false,
        })
            .as('post_details')
            .then((response) => {
                let id = response.body['id']
                expect(response.status).to.eq(200)
                cy.request({
                    method: 'GET',
                    url: get_url + id,
                    failOnStatusCode: false,
                })
                    .as('get_details')
                    .then((response) => {
                        expect(response.status).to.eq(200)
                        Object.assign(put_body, { id: id })
                        cy.request({
                            method: 'PUT',
                            url: put_url,
                            body: put_body,
                            failOnStatusCode: false,
                        })
                            .as('put_details')
                            .then((response) => {
                                expect(response.status).to.eq(200)
                            })
                    })
                    .then((response) => {
                        expect(response.status).to.eq(200)
                        cy.request({
                            method: 'DELETE',
                            url: delete_url + id,
                            failOnStatusCode: false,
                        })
                            .as('delete_details')
                            .then((response) => {
                                expect(response.status).to.eq(200)
                            })
                    })
            })
    }

    static PostSimple(body, post_url, code) {
        cy.request({
            method: 'POST',
            url: post_url,
            body: body,
            failOnStatusCode: false,
        })
            .as('post_details')
            .then((response) => {
                expect(response.status).to.eq(code)
            })
    }

    static GetSimple(body, get_url, code) {
        cy.request({
            method: 'Get',
            url: get_url,
            body: body,
            failOnStatusCode: false,
        })
            .as('get_details')
            .then((response) => {
                expect(response.status).to.eq(code)
            })
    }

    static PutSimple(body, put_url, code) {
        cy.request({
            method: 'PUT',
            url: put_url,
            body: body,
            failOnStatusCode: false,
        })
            .as('put_details')
            .then((response) => {
                expect(response.status).to.eq(code)
            })
    }

    static PostGetPutDeleteForTargetdata(
        body,
        put_body,
        post_url,
        get_url,
        put_url,
        delete_url,
        satelliteID
    ) {
        cy.request({
            method: 'POST',
            url: post_url,
            body: body,
            failOnStatusCode: false,
        })
            .as('post_details')
            .then((response) => {
                expect(response.status).to.eq(200)
                cy.wait(1000)
                cy.request({
                    method: 'GET',
                    url: get_url + '/' + satelliteID,
                    failOnStatusCode: false,
                })
                    .as('get_details')
                    .then((response) => {
                        expect(response.status).to.eq(200)
                        cy.wait(1000)
                        cy.request({
                            method: 'PUT',
                            url: put_url,
                            body: put_body,
                            failOnStatusCode: false,
                        })
                            .as('put_details')
                            .then((response) => {
                                expect(response.status).to.eq(200)
                            })
                    })
                // .then((response) => {
                //     expect(response.status).to.eq(200)
                //     cy.request({
                //         method: 'DELETE',
                //         url: delete_url + satelliteID,
                //         failOnStatusCode: false,
                //     })
                //         .as('delete_details')
                //         .then((response) => {
                //             expect(response.status).to.eq(200)
                //         })
                // })
            })
    }

    static PostGetPutDeleteForMTO(
        body,
        put_body,
        post_url,
        get_url,
        put_url,
        delete_url,
        today,
        todayPlusTen
    ) {
        Object.assign(body, { timestamp: today })
        Object.assign(body, { periodStart: today })
        Object.assign(body, { periodEnd: todayPlusTen })
        Object.assign(put_body, { timestamp: today })
        Object.assign(put_body, { periodStart: today })
        Object.assign(put_body, { periodEnd: todayPlusTen })

        cy.request({
            method: 'POST',
            url: post_url,
            body: body,
            failOnStatusCode: false,
        })
            .as('post_details')
            .then((response) => {
                expect(response.status).to.eq(200)
                cy.wait(1000)
                cy.request({
                    method: 'GET',
                    url: get_url,
                    failOnStatusCode: false,
                })
                    .as('get_details')
                    .then((response) => {
                        expect(response.status).to.eq(200)
                        cy.request({
                            method: 'PUT',
                            url: put_url,
                            body: put_body,
                            failOnStatusCode: false,
                        })
                            .as('put_details')
                            .then((response) => {
                                expect(response.status).to.eq(200)
                            })
                    })
                    .then((response) => {
                        expect(response.status).to.eq(200)
                        //     cy.request({
                        //         method: 'DELETE',
                        //         url: delete_url,
                        //         body: put_body,
                        //         failOnStatusCode: false,
                        //     })
                        //         .as('delete_details')
                        //         .then((response) => {
                        //             expect(response.status).to.eq(200)
                        //         })
                        // })
                    })
            })
    }
}
