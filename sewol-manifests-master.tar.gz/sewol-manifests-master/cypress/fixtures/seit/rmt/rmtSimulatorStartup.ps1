######################################################################################################################
# This software was developed pursuant to a Classified Contract Number with the U.S. Government.
# The U.S. government's rights in and to this copyrighted software are as specified in
# DFARS 252.227-7014 which was made part of the above contract.
#
# WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
# Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
# C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
#
# This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
# to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
# completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
#
# Violations are subject to severe criminal penalties.
######################################################################################################################

$STAGING_URI = if ($STAGING_URI) {$STAGING_URI} else {'https://sewol.staging.dso.mil'}

[System.Uri]$Uri = "$STAGING_URI" # Add the Uri
$Cookie = New-Object System.Net.Cookie
$Cookie.Name = if ($STAGING_COOKIE_NAME) {$STAGING_COOKIE_NAME} else { "__Host-sewol-staging-authservice-session-id-cookie" } # Add the name of the cookie
$Cookie.Value = "${STAGING_COOKIE}" # Add the value of the cookie
$Cookie.Domain = $uri.DnsSafeHost

$WebSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$WebSession.Cookies.Add($Cookie)

$Headers = @{
    "Content-Type" = "application/json"
}
$RMTid = 'RMT-8'

# Add RMT
$Body = @{
    "rmtId" = $RMTid
} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri $STAGING_URI/coi-rmt-simulator/rmt/add -Body $Body -Headers $Headers -WebSession $WebSession
Start-Sleep -Seconds 1

# Start RMT
Invoke-RestMethod -Method Post -Uri $STAGING_URI/coi-rmt-simulator/rmt/start -Body $Body -Headers $Headers -WebSession $WebSession
Start-Sleep -Seconds 1

# RMT StartUpEvent
$EventMessage = Get-Content -Raw StartUpEvent_${RMTid}.json
$EventMessage = $EventMessage -replace [System.Environment]::NewLine, ""
$FutureTime = (Get-Date).AddSeconds(2).Date
$FutureTime = Get-Date $FutureTime -Format "yyyy-MM-ddTHH:mm:ss.000Z"
$Body = @{
    "eventType" = "StartUpEvent"
    "rmtId" = $RMTid
    "message" = $EventMessage
    "simulationTime" = $FutureTime
} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri $STAGING_URI/coi-rmt-simulator/event/ -Body $Body -Headers $Headers -WebSession $WebSession

# RMT Periodic Events
$periodic_events = 'HealthAndStatus','HeartbeatEvent','BITResultsEvent','AntennaStatusEvent','ReceiverTuneEvent','TransmitStateEvent'
foreach ($periodic_event in $periodic_events)
{
    $EventMessage = Get-Content -Raw ${periodic_event}_${RMTid}.json
    $EventMessage = $EventMessage -replace [System.Environment]::NewLine, ""
    $FutureTime = (Get-Date).AddSeconds(2).Date
    $FutureTime = Get-Date $FutureTime -Format "yyyy-MM-ddTHH:mm:ss.000Z"
    $Body = @{
        "eventType" = $periodic_event
        "rmtId" = $RMTid
        "message" = $EventMessage
        "simulationTime" = $FutureTime
        "periodInSeconds" = 10
        "timestampSubstitutionToken" = "TOBEREPLACED"
    } | ConvertTo-Json
    Invoke-RestMethod -Method Post -Uri $STAGING_URI/coi-rmt-simulator/event/periodic/ -Body $Body -Headers $Headers -WebSession $WebSession
}

