/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

const shortMonths = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

export const convertToMtoTime = (timestamp) => {
    // Input: millis; Output DDHHMMZMMMYY, e.g. 310000ZJAN24
    const dateObject = new Date(timestamp)
    const day = dateObject.getDate().toLocaleString('en-US', {
        minimumIntegerDigits: 2,
        useGrouping: false
    })
    const hour = dateObject.getHours().toLocaleString('en-US', {
        minimumIntegerDigits: 2,
        useGrouping: false
    })
    const minute = dateObject.getMinutes().toLocaleString('en-US', {
        minimumIntegerDigits: 2,
        useGrouping: false
    })
    const month = shortMonths[dateObject.getMonth()]
    const year = dateObject.getFullYear() % 100
    const dateString = day.concat(hour, minute, "Z", month, year)
    return dateString
}

export const convertMtoTimeToMillis = (timestamp) => {
    // Input: DDHHMMZMMMYY, e.g. 310000ZJAN24; Output millis
    const day = timestamp.substring(0, 2)
    const hour = timestamp.substring(2, 4)
    const minute = timestamp.substring(4, 6)
    const monthInt = shortMonths.findIndex((element) => element == timestamp.substring(7, 10)) + 1
    const month = monthInt.toLocaleString('en-US', {
        minimumIntegerDigits: 2,
        useGrouping: false
    })
    const year = '20' + timestamp.substring(10)
    const dateMillis = Date.parse(year + '-' + month + '-' + day + 'T' + hour + ':' + minute + ':00.000Z')
    return dateMillis
}

