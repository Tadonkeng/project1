/***********************************************************************************************************************
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/

/*
 * This is a reverse proxy for use in testing SEWOL in E2E tests.  It simulates 
 * the Kubernetes ingress and Keycloak that routes requests and injects a JWT token.
 */

const fs = require('fs');
const express = require('express');
const hpm = require('http-proxy-middleware');
const RbacUtils = require('../../fixtures/common/rbacUtils.cjs');

const app = express();
var server = null;
var jwt = null;
var cookie = null;

// Set the JWT for a given user (the user must appear in casl_data.json)
function setUser(userid) {

  // If a cookie was provided, then don't set a JWT
  if (cookie) {
     return
  }

  if (userid == null) {
     clearJwt();
     return
  }

  // Read the CASL JSON file
  const caslDataRaw = fs.readFileSync("../fixtures/common/casl_data.json");
  const caslDataJson = JSON.parse(caslDataRaw); 

  if (!(userid in caslDataJson.users)) {
    console.log('ERROR: User ' + userid + ' not found in CASL data');
    throw 'ERROR: User ' + userid + ' not found in CASL data';
  }

  userData = caslDataJson.users[userid];

  jwt = RbacUtils.genJwtToken(userData);
}

// Unset the user by clearing the JWT 
function unsetUser() {
  jwt = null 
}

// Start the Reverse Proxy
function start(proxyPort, defaultUrl, sessionCookie, routerTable, pathRewriteTable) {

  if (sessionCookie) {
    cookie = "__Host-sewol-staging-authservice-session-id-cookie=" + sessionCookie
  }

  //console.log("proxyPort : " + proxyPort);
  //console.log("defaultUrl : " + defaultUrl);
  //console.log("routerTable : " + JSON.stringify(routerTable));
  //console.log("pathRewriteTable : " + [...pathRewriteTable.entries()]);

  // proxy middleware options
  // @type {import('http-proxy-middleware/dist/types').Options}
  const options = {
    target: defaultUrl,    // default target - Staging environment
    changeOrigin: true,    // needed for virtual hosted sites
    hostRewrite: true,
    ws: true,              // proxy websockets
    router: routerTable,   // router table for alternate targets by path
   
    // Perform path rewrite
    // @param path - The path of the request
    // @param {http.IncomingMessage} req - Client request that was received
    pathRewrite: function(path, req) {
      for (const [pattern, replacement] of pathRewriteTable) {
        if (path.includes(pattern)) {
          //console.log("Initial request path: " + path);
          path = path.replace(pattern, replacement);   
          //console.log("Rewriten request path: " + path);
          return path;
        }
      }
      //console.log("Unmodified request path: " + path);
      return path;
    },

   
    // Handler for HTTP requests 
    // @param {http.ClientRequest} proxyReq - Proxy request that will be sent
    // @param {http.IncomingMessage} req - Client request that was received
    // @param {http.ServerResponse} res - Client response that will be returned 
    onProxyReq: function(proxyReq, req, res) {

      // Add the authorization header with the JWT
      if (jwt != null) { 
          proxyReq.setHeader('authorization', jwt);
      }
      // Or, add the cookie header
      else if (cookie != null) { 
          proxyReq.setHeader('cookie', cookie);
      }

      //console.log("-----------------------------------------------------------------");
      //console.log("REQUEST: " + req.method + " " + req.protocol + " " + req.url);
      //console.log("req.httpVersion: " + req.httpVersion);
      //console.log("proxyReq.reusedSocket: " + proxyReq.reusedSocket);
      //console.log("Request headers: " + JSON.stringify(proxyReq.getHeaders()));
      //console.log("Path: " + req.path);
      //console.log("Method: " + req.method);
      //console.log("Host " + req.hostname);
      //console.log("Protocol " + req.protocol);
    },

    // Handler for WebSocket requests 
    onProxyReqWs: function(proxyReq, req, socket, options, head) {

      //console.log("WS URL: " + options.target.href);
      let hostUrl = new URL(options.target.href);
      let host = hostUrl.hostname
      //console.log("WebSocket request setting host=" + host)
      proxyReq.setHeader("host", host);

      let origin = hostUrl.protocol + "//" + host
      //console.log("WebSocket request setting origin=" + origin)
      proxyReq.setHeader("origin", origin);
  
      // Add the authorization header with the JWT
      if (jwt != null) { 
         proxyReq.setHeader('authorization', jwt);
      }
      // Or, add the cookie header
      else if (cookie != null) { 
          proxyReq.setHeader('cookie', cookie);
      }
    },

    // Handler for HTTP responses 
    // @param {http.IncomingMessage} proxyRes - Proxy response that was received
    // @param {http.IncomingMessage} req - Client request that was received
    // @param {http.ServerResponse} res - Client response that will be returned 
    onProxyRes: function(proxyRes, req, res) {

      //console.log("-----------------------------------------------------------------");
      //console.log("RESPONSE: " + req.method + " " + req.url);
      //console.log("Status code: " + proxyRes.statusCode);
      //console.log("proxyRes.httpVersion: " + proxyRes.httpVersion);
      //console.log("req.httpVersion: " + req.httpVersion);
      //console.log("Response headers: " + JSON.stringify(proxyRes.headers));

      // For any redirects, update the redirect to point back at this proxy
      if ([301, 307, 308].indexOf(proxyRes.statusCode) > -1 && proxyRes.headers.location) {
          var redirect = new URL(proxyRes.headers.location);
          //console.log("Redirect URL: " + redirect.toString());
          redirect.host = 'localhost';
          redirect.port = proxyPort;
          proxyRes.headers.location = redirect.toString();
          //console.log("Updated Redirect URL: " + redirect.toString());
      }
    },

    onError: function(err, req, res, target) {
      console.log("Error: " + err);
    },

    //logLevel: 'debug'
    logLevel: 'warn'
  };

  // create the proxy (without context)
  const proxy = hpm.createProxyMiddleware(options);

  // mount proxy in web server
  app.use('/', proxy);

  // Start the server
  server = app.listen(proxyPort);
  server.on("upgrade", proxy.upgrade);
}

// Stop the Reverse Proxy
function stop() {
  if (server != null) {
    server.close();
    server = null;
  }
};

module.exports = { setUser, unsetUser, start, stop };
