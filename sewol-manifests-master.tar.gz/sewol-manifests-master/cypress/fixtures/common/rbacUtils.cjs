/***********************************************************************************************************************
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 * 
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 * 
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 * 
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
const fs = require("fs");
const raw_data = fs.readFileSync(__dirname + "/../../fixtures/common/casl_data.json");
const CaslData = JSON.parse(raw_data);

class RbacUtils {

    /**
     * Funciton runs another method after first populating the current role
     * service with current roles for the given users. Once the argument
     * function is has completed or thrown an exception, the users and their
     * roles are removed from the current role servie database.
     */
    static doInPopulatedCurRoleService(users, exc) {
        try {

            // populate user current role db.
            for (let user of users) {
                if (user.current_role) {
                    this.setUserRole(user.payload.usercertificate, 
                        user.current_role)
                }
            }
            
            // wait 1 to avoid race conditions
            setTimeout('', 1000)

            // execute
            exc()

        } finally {

            // we always want to unset the roles
            
            //wait 1 to avoid race conditions
            setTimeout('', 1000)

            // depopulate db.
            for (let user of users) {
                if (user.current_role) {
                    this.deleteUserRole(user.payload.usercertificate,
                        user.current_role)
                }
            }
        }
    }

    /**
     * Generate a jwt bearer token for the user.
     * @param {*} user 
     */
    static genJwtToken(user) {
        let header = btoa(JSON.stringify(CaslData.jwt_header))
        let payload = btoa(JSON.stringify(user.payload))
        let signature = btoa(JSON.stringify(CaslData.jwt_signature))
        return "Bearer " + header + "." + payload + "." + signature;
    }
    
    /**
     * Make call to set current role for userid in current role service
     * @param {*} userid 
     * @param {*} role 
     */
    static setUserRole(userid, role) {
        it ('Pre-populating current role service db with ' + userid + ": " + role, 
        () => {
            let path = "/data-service/admin/set-current-role"
            let params = "?userId=" + userid + "&role=" + role
            cy.request({
                method: 'PUT',
                url: Cypress.config('baseUrl') + path + params,
                failOnStatusCode: false
            }).then((response) => {
                expect(response.status).to.eq(200)
            })  
        })
        
    }

    /**
     * Make call to unset current role for userid in current role service
     * @param {*} userid 
     */
    static deleteUserRole(userid) {
        it ('De-populating current role db for userid: ' + userid, () => {
            let path = "/data-service/admin/delete-current-role"
            let params = "?userId=" + userid
            cy.request({
                method: 'DELETE',
                url: Cypress.config('baseUrl') + path + params,
                failOnStatusCode: false
            }).then((response) => {
                expect(response.status).to.eq(200)
            })
        })
        
    }
}

module.exports = RbacUtils;
