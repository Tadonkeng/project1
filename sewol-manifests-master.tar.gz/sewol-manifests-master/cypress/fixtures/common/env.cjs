function expand(string) {
  if (!string)
    throw new Error('Null string')

  // Expand env vars formatted as: ${name}
  let regExVal1 = "\\$\\{([\\w]+?)\\}"
  const regEx1 = new RegExp(regExVal1, "g")
  pass1 = string.replaceAll(regEx1, function(match) {
    let varName = match.match(new RegExp(regExVal1))[1];
    return process.env[varName];
  });

  // Expand env vars formatted as: $name
  let regExVal2 = "\\$([\\w]+)"
  const regEx2 = new RegExp(regExVal2, "g")
  pass2 = pass1.replaceAll(regEx2, function(match) {
    let varName = match.match(new RegExp(regExVal2))[1];
    return process.env[varName];
  });

  return pass2;
}

module.exports = { expand };
