/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */
import '@4tw/cypress-drag-drop'
import SewSystemCapabilities from '../../../support/sewcop/model/SewSystemCapabilities.js';
import TargetData from '../../../support/sewcop/model/TargetData.js';
import MissionPlan from '../../../support/sewcop/model/MissionPlan.js';

describe("SEWCOP Auto-Populate Mission Folders", function() {
    it("from Mission Plan", function() {

        deleteAllMissionPlans();

        // Generate and ingest 3 RMTs.
        let rmtId1 = genRandomRmtId();
        let rmtId2 = genRandomRmtId();
        let rmtId3 = genRandomRmtId();

        cy.coiRmtSimStart(rmtId1);
        cy.coiRmtSimStart(rmtId2);
        cy.coiRmtSimStart(rmtId3);

        cy.coiRmtSimStartUpEvent(rmtId1);
        cy.coiRmtSimStartUpEvent(rmtId2);
        cy.coiRmtSimStartUpEvent(rmtId3);

        cy.wait(5000);

        new SewSystemCapabilities(rmtId1);
        new SewSystemCapabilities(rmtId2);
        new SewSystemCapabilities(rmtId3);

        cy.get(`@${SewSystemCapabilities.getJsonAlias(rmtId1)}`).then(sewSystemCapabilitiesJson => {
            waitForSewSystemStatus(sewSystemCapabilitiesJson.sewSystemUuid, 31);
        });
        cy.get(`@${SewSystemCapabilities.getJsonAlias(rmtId2)}`).then(sewSystemCapabilitiesJson => {
            waitForSewSystemStatus(sewSystemCapabilitiesJson.sewSystemUuid, 31);
        });
        cy.get(`@${SewSystemCapabilities.getJsonAlias(rmtId3)}`).then(sewSystemCapabilitiesJson => {
            waitForSewSystemStatus(sewSystemCapabilitiesJson.sewSystemUuid, 31);
        });

        // Generate and ingest 3 targets.
        let soi1 = crypto.randomUUID();
        let soi2 = crypto.randomUUID();
        let soi3 = crypto.randomUUID();

        let targetData1 = new TargetData(soi1);
        targetData1.createRemote();
        let targetData2 = new TargetData(soi2);
        targetData2.createRemote();
        let targetData3 = new TargetData(soi3);
        targetData3.createRemote();

        // Generate and ingest a mission plan
        let planNumber = Math.floor(Math.random() * 99999);
        let planName = "MTO-" + planNumber;
        let weaponTargetAssignment = new Map();

        // At first, our MissionPlan will only have 2 targets with no tasks against them.
        weaponTargetAssignment.set(soi1, []);
        weaponTargetAssignment.set(soi2, []);
        let missionPlan = new MissionPlan(planName, planNumber, weaponTargetAssignment);
        missionPlan.createRemote();

        // Log into rtiles.
        cy.login('Xavier');

        cy.visit({
            url: 'rtiles/',
            failOnStatusCode: false
        });

        // Select the role from the RTiles display
        cy.get('#role-select-modal-prompt-option').select('TRAINER');
        cy.get('#role-select-modal-submit').click();

        // Hover over the Tile Selection tab and drag Mission Folders to the layout
        cy.get('.mdi-developer-board').trigger('mouseover');

        cy.get('#dragtile-case-folder-tile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-case-folder-tile > .info-border').trigger('mouseup', {force:true});

        // Open the mission folder associated with the previously created mission plan.
        cy.get('.cf-tabs-list').contains(`MTO-${planName}`).click();

        // Alias mission plan card folder element.
        let missionFolder = 'missionFolderForMissionPlan';
        cy.get(`div[id="MTO-${planName.replace(' ', '-')}-card-panel"]`).as(`${missionFolder}`);
        
        // Check that just our 2 targets are in the mission folder. This demonstrates CAP123-F01.
        cy.get(`@${missionFolder}`).contains(soi1);
        cy.get(`@${missionFolder}`).contains(soi2);
        cy.get(`@${missionFolder}`).contains(soi3).should('not.exist');

        // Update the mission plan by adding a new target.
        missionPlan.updateWeaponTargetAssignment((weaponTargetAssignment) => {
            weaponTargetAssignment.set(soi3, []);
        });
        missionPlan.updateRemote();

        // Check that the target was added to the mission folder. This demonstrates CAP123-F02.
        cy.get(`@${missionFolder}`).contains(soi3);

        // Update the mission plan to task 2 of the rmts against 2 of the targets.
        missionPlan.updateWeaponTargetAssignment((weaponTargetAssignment) => {
            weaponTargetAssignment.get(soi1).push(rmtId2);
            weaponTargetAssignment.get(soi3).push(rmtId2, rmtId3);
        });
        missionPlan.updateRemote();

        // Check that rmt 2 and rmt 3 are in the mission folder but rmt 1 is not. 
        // This demonstrates CAP123-F04.
        cy.get(`@${missionFolder}`).contains(rmtId1).should('not.exist');
        cy.get(`@${missionFolder}`).contains(rmtId2);
        cy.get(`@${missionFolder}`).contains(rmtId3);

        // Check that the soi2 target card indicates it has no tasks against it and the
        // soi1 and 3 cards indicate that they have tasks assigned against them. 
        // This demonstrates CAP123-F07.
        cy.get(`@${missionFolder}`).find(`[data-objname="${soi1}"]`).find('i.alert-icon')
            .should('have.class', 'assigned-target-icon');
        cy.get(`@${missionFolder}`).find(`[data-objname="${soi2}"]`).find('i.alert-icon')
            .should('have.class', 'unassigned-target-icon');
        cy.get(`@${missionFolder}`).find(`[data-objname="${soi3}"]`).find('i.alert-icon')
            .should('have.class', 'assigned-target-icon');

        // Update the mission plan to delete target with soi 1 and re-assign sew tasks such that
        // rmt 3 is no longer tasked.
        missionPlan.updateWeaponTargetAssignment((weaponTargetAssignment) => {
            weaponTargetAssignment.delete(soi1);
            weaponTargetAssignment.get(soi2).push(rmtId1);
            weaponTargetAssignment.set(soi3, [rmtId2]);
        });
        missionPlan.updateRemote();

        // Check that the target card for soi 1 is no longer present. This demonstrates CAP123-F05.
        cy.get(`@${missionFolder}`).contains(soi1).should('not.exist');
        cy.get(`@${missionFolder}`).contains(soi2);
        cy.get(`@${missionFolder}`).contains(soi3);

        // Check that the rmt 3 target card is no longer in the mission folder.
        // This demonstrates CAP123-F06.
        cy.get(`@${missionFolder}`).contains(rmtId1);
        cy.get(`@${missionFolder}`).contains(rmtId2);
        cy.get(`@${missionFolder}`).contains(rmtId3).should('not.exist');

        // Check that the user cannot remove entities from the autopopulated mission folder. Check 1.1.
        cy.get(`@${missionFolder}`).find('.delete-cf-item').should('not.exist');

        // Create a new user-created mission folder.
        let cfAddDiv = "divForAddingCaseFolderByName";
        let userCaseFolder = 'x' + crypto.randomUUID();
        cy.get('.casefolder-container').find('.case-folder-add').parent().as(cfAddDiv);
        cy.get(`@${cfAddDiv}`).find('input').type(userCaseFolder);
        cy.get(`@${cfAddDiv}`).find('i').click();
        cy.get('.cf-tabs-list').contains(`${userCaseFolder}`);
        
        // Check that a user cannot create a case folder that starts with "MTO-". Check 1.2.
        cy.get(`@${cfAddDiv}`).find('input').type("{backspace}".repeat(37));
        cy.get(`@${cfAddDiv}`).find('input').type("MTO-" + userCaseFolder);
        cy.get(`@${cfAddDiv}`).find('i').click();
        cy.get('.cf-tabs-list').contains(`MTO-${userCaseFolder}`).should('not.exist');

        // Nav to All folder and check that the user can add soi1 and rmt 3 (which are currently not
        // in the MTO case folder) to the user generated case folder but not to the 
        // auto populated MTO case folder. Check 1.3.
        cy.get('.cf-tabs-list').contains('All').click();
        let allFolder = "allFolderDiv";
        cy.get(`div[id="All"]`).as(`${allFolder}`);
        // First the rmt.
        cy.get(`@${allFolder}`).find(`[data-objname="${rmtId3}"]`).parent().find('.mdi-folder-plus').click();
        cy.get(`ul[class="add-to-folder-menu-options"]`).contains(`MTO-${planName}`).should('not.exist');
        cy.get(`ul[class="add-to-folder-menu-options"]`).contains('a', `${userCaseFolder}`).click();
        // Then the target.
        cy.get(`@${allFolder}`).find(`[data-objname="${soi1}"]`).parent().find('.mdi-folder-plus').click();
        cy.get(`ul[class="add-to-folder-menu-options"]`).contains(`MTO-${planName}`).should('not.exist');
        cy.get(`ul[class="add-to-folder-menu-options"]`).contains('a', `${userCaseFolder}`).click();
        // Finally, check that the entities were added to the custom folder.
        cy.get('.cf-tabs-list').contains(`${userCaseFolder}`).click();
        cy.get(`div[id="${userCaseFolder}"]`).as(`${userCaseFolder}`);
        cy.get(`@${userCaseFolder}`).contains(soi1);
        cy.get(`@${userCaseFolder}`).contains(soi2).should('not.exist');
        cy.get(`@${userCaseFolder}`).contains(rmtId3);

        // Check that a user can delete the mission folder they created but they cannot
        // delete the auto-populated one.
        // This check, combined with checks 1.1 through 1.3, demonstrates CAP123-F08.
        cy.get('.cf-tabs-list').find(`[aria-controls="MTO-${planName}"]`).find('.removeCF').should('not.exist');
        cy.get('.cf-tabs-list').contains(`MTO-${planName}`).click();
        cy.get('.cf-tabs-list').find(`[aria-controls="${userCaseFolder}"]`).find('span.removeCF').click();
        cy.get('.cf-tabs-list').contains(`${userCaseFolder}`).should('not.exist');

        // Generate a new mission plan that expired 10 seconds less than 2 days ago.
        planNumber = Math.floor(Math.random() * 99999);
        planName = "MTO-" + planNumber;
        let secondWeaponTargetAssignment = new Map();

        // All targets have sews tasked against them.
        secondWeaponTargetAssignment.set(soi1, [rmtId1]);
        secondWeaponTargetAssignment.set(soi2, [rmtId2]);
        secondWeaponTargetAssignment.set(soi3, [rmtId3]);
        cy.wrap().then(() => { // we need this to run at cypress time, not test-code time.
            missionPlan = new MissionPlan(planName, planNumber, secondWeaponTargetAssignment, 
                (Date.now() + (-172800000) + (-30000)), (Date.now() + (-172800000) + (10000)));
            missionPlan.createRemote();
        });

        // Check that all 3 tasked rmts are in the mission folder. This demonstrates CAP123-F09.
        cy.get('.cf-tabs-list').contains(`MTO-${planName}`).click();
        cy.get(`div[id="MTO-${planName.replace(' ', '-')}-card-panel"]`).as(`${missionFolder}`);
        cy.get(`@${missionFolder}`).contains(rmtId1);
        cy.get(`@${missionFolder}`).contains(rmtId2);
        cy.get(`@${missionFolder}`).contains(rmtId3);

        // Check that after waiting until this mission folder's MTO has been expired for 2 days,
        // the auto populated mission folder is deleted within one minute. This demonstrates CAP123-F03.
        cy.wait(12000);
        cy.get('.cf-tabs-list').contains(`MTO-${planName}`, {timeout: 60000}).should('not.exist');
    });
});

function genRandomRmtId() {
    return "RMT-" + ("" + (Math.random() * 10)).replace(".", '');
}

function deleteAllMissionPlans() {
    cy.request({
        method: 'GET',
        url: 'data-service/missionPlan'
    }).then(response => {
        for(const missionPlan of response.body) {
            cy.request({
                method: 'DELETE',
                url: 'data-service/missionPlan/' + missionPlan.number
            });
        }
    });
}

function waitForSewSystemStatus(sewSystemUuid, numberOfSearchAttempts) {
    if (numberOfSearchAttempts <= 0) {
        throw new Exception(`Could not get SewSystemStatus from endpoint for sew system with uuid ${sewSystemUuid} after many re-tries.`);
    }
    cy.request({
        method: 'GET',
        url: '/data-service/sewol/sewSystemStatus/' + sewSystemUuid
    }).then(response => {
        if ((response.body.sewSystemUuid != sewSystemUuid) && (numberOfSearchAttempts > 0)) {
            cy.wait(1000);
            waitForSewSystemStatus(sewSystemUuid, numberOfSearchAttempts - 1);
        }
    });
}
