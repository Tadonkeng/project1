/***********************************************************************************************************************
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 * 
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 * 
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 * 
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import '@4tw/cypress-drag-drop'

describe('RMT Location Test', () => {

  // C051-F03
  it('open a SEW System detail card and check the lat/long/alt', () => {

    const rmtId = "RMT-9";

    // Add and start RMT
    cy.coiRmtSimAdd(rmtId)
    cy.coiRmtSimStart(rmtId)

    //Send event message
    cy.coiRmtSimStartUpEvent(rmtId);
    // allow time for event to process before running next test which verifies
    cy.wait(5000);

    cy.login('Xavier');

    // Visit Rtiles
    cy.login('Xavier');
    cy.visit({
      url: '/',
      failOnStatusCode: false
    });

    // Select the role from the RTiles display
    cy.get('#role-select-modal-prompt-option').select('SEW_OPERATOR');
    cy.get('#role-select-modal-submit').click();

    // Hover over the Tile Selection tab and drag Mission Folders to the layout
    cy.get('.mdi-developer-board').trigger('mouseover');

    cy.get('#dragtile-case-folder-tile > .info-border').drag('.lm_goldenlayout', {force:true})
    cy.get('#dragtile-case-folder-tile > .info-border').trigger('mouseup', {force:true});

    // Wait for the Mission Folders to be populated on the screen, by verifying
    // that the folder tabs are visible.
    cy.get('.cf-tabs-list').should('be.visible');

    // Select the All folder
    cy.get('.ui-tabs-anchor > .caseFolderName').contains('All').click();

    // Click on the SEW System brief card to open the detail card
    cy.get('[data-type="SEWSYSTEM"][data-objname="' + rmtId + '"] > .table-card').click();

    // Scroll down to the LLA values on the card
    cy.get('#bbcard-cfobj-details > div').scrollTo(0, 500);

    // Check the latitude, longitude, and altitude
    cy.get('#sewsystem-cfobj-latitude').should('have.text', "33.983612°");
    cy.get('#sewsystem-cfobj-longitude').should('have.text', "-118.425°");
    cy.get('#sewsystem-cfobj-altitude').should('have.text', "0 ft");
    cy.screenshot('SewDetailCard');

    // Close the detail card
    cy.get('.close-modal-bbcard').click()

    // Get the data-id of the C21000 trget brief card
    cy.get('[data-type="SEWSYSTEM"][data-objname="' + rmtId + '"]').invoke('attr', 'data-id').then((idValue) =>  {
      cy.request('GET', '/data-service/sewol/sewSystemCapabilities/' + idValue, {}).then(
        (response) => {
          expect(response.body.antennas[0]).to.have.property('latitude', 33.983612)
          expect(response.body.antennas[0]).to.have.property('longitude', -118.425)
          expect(response.body.antennas[0]).to.have.property('altitude', 0)
      })
    })

    cy.coiRmtSimDelete(rmtId)
    cy.logout('Xavier');
  })
})
