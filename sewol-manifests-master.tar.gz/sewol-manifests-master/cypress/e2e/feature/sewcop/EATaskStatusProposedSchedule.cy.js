/***********************************************************************************************************************
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 * 
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 * 
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 * 
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import '@4tw/cypress-drag-drop'

// SEWCOP E2E test for C105
describe('SEWCOP Display EA/ES Task', () => {

    // Variables
    let user = 'Xavier';
    let user_role = 'SEW_OPERATOR';
    let sew_task_url = '/data-service/sewTask';
    let sew_capability_url = '/data-service/sewol/sewSystemCapabilities';
    let target_url = '/repository/targetData';
    let statusCode = 200;
    let rmtId1 = 'RMT-' + ('' + (Math.random() * 10)).replace('.', '');
    let rmtId2 = 'RMT-' + ('' + (Math.random() * 10)).replace('.', '');
    let targetId1 = 'Target-' + crypto.randomUUID();
    let targetId2 = 'Target-' + crypto.randomUUID();
    let esTaskId = crypto.randomUUID();
    let eaTaskId = crypto.randomUUID();
    let esTaskName = 'ES Task Test';
    let eaTaskName = 'EA Task Test';
    let esTaskType = 'ES';
    let eaTaskType = 'ES_EA';

    // Execute before test
    before(() => {
        // Create RMTs
        cy.coiRmtSimStart(rmtId1);
        cy.coiRmtSimStartUpEvent(rmtId1);
        cy.coiRmtSimStart(rmtId2);
        cy.coiRmtSimStartUpEvent(rmtId2);
        cy.wait(10000); // RMTs take longer to post

        // Create targets
        cy.fixture('seit/mars_attacks_es_target_data').then((targetData) => {
            let target1 = targetData[0];
            target1.soiDesignator = targetId1;
            target1.uplink.satellite = '1';
            cy.request({
                method: 'POST',
                url: target_url,
                body: target1
            })
            .then((response) => {
                expect(response.status).to.equals(statusCode)

                let target2 = targetData[0];
                target2.soiDesignator = targetId2;
                target2.uplink.satellite = '1';
                cy.request({
                    method: 'POST',
                    url: target_url,
                    body: target2
                })
                .then((response) => {
                    expect(response.status).to.equals(statusCode)
                })
            })
        })

        // Get SEW ID
        cy.request({
            method: 'GET',
            url: sew_capability_url
        })
        .then((response) => {
            let sewId1 = '';
            let sewId2 = '';
            response.body.forEach((sewCapability) => {
                if (sewCapability.sewSystemName == rmtId1) {
                    sewId1 = sewCapability.sewSystemUuid;
                }

                if (sewCapability.sewSystemName == rmtId2) {
                    sewId2 = sewCapability.sewSystemUuid;
                }
            })

            // Set SEW task json
            cy.fixture('sewcop/SewTaskExample1.json').then((sewTaskJson) => {
                let updatedTaskJson = sewTaskJson;
                updatedTaskJson.schedState = 'PROPOSED';
                let startTime = new Date();
                updatedTaskJson.startTime = startTime.toISOString();
                let endTime = startTime;
                endTime.setDate(startTime.getDate() + 1); // Task ends after 1 day
                updatedTaskJson.endTime = endTime.toISOString();

                // Create ES task
                let esSewTask = updatedTaskJson;
                esSewTask.sewSystemUuid = sewId1;
                esSewTask.sewSystemName = rmtId1;
                esSewTask.taskingGroupId = esTaskId;
                esSewTask.taskName = esTaskName;
                esSewTask.taskType = esTaskType;
                esSewTask.targetDetails.targetName = targetId1; // Assign task to target 1
                cy.request({
                    method: 'POST',
                    url: sew_task_url,
                    body: esSewTask
                })
                .then((response) => {
                    expect(response.status).to.eq(statusCode)

                    // Create EA task
                    let eaSewTask = updatedTaskJson;
                    eaSewTask.sewSystemUuid = sewId2;
                    eaSewTask.sewSystemName = rmtId2;
                    eaSewTask.taskingGroupId = eaTaskId;
                    eaSewTask.taskName = eaTaskName;
                    eaSewTask.taskType = eaTaskType; // For PI4
                    eaSewTask.targetDetails.targetName = targetId2; // Assign task to target 2
                    cy.request({
                        method: 'POST',
                        url: sew_task_url,
                        body: eaSewTask
                    })
                    .then((response) => {
                        expect(response.status).to.eq(statusCode)
                    })
                })
            })
        })

        // Login with permissions
        cy.login(user);
    })

    // Execute after test
    after(() => {
        // Delete SEW tasks
        cy.request({
            method: 'DELETE',
            url: sew_task_url + '/' + esTaskId
        })
        .then((response) => {
            expect(response.status).to.eq(statusCode)
        })

        cy.request({
            method: 'DELETE',
            url: sew_task_url + '/' + eaTaskId
        })
        .then((response) => {
            expect(response.status).to.eq(statusCode)
        })

        // Delete RMTs
        cy.coiRmtSimDelete(rmtId1);
        cy.coiRmtSimDelete(rmtId2);

        // Delete targets
        cy.request({
            method: 'DELETE',
            url: target_url + '/' + targetId1
        })
        .then((response) => {
            expect(response.status).to.equals(statusCode)
        })

        cy.request({
            method: 'DELETE',
            url: target_url + '/' + targetId2
        })
        .then((response) => {
            expect(response.status).to.equals(statusCode)
        })

        // Logout
        cy.logout(user);
    })

    // Test ES/EA SEW task changes on proposed schedule
    it('Updates on Proposed Schedule', () => {
        // Visit Rtiles
        cy.visit({
            url: '/',
            failOnStatusCode: false
        });

        // Select the role from the RTiles display
        cy.get('#role-select-modal-prompt-option').select(user_role);
        cy.get('#role-select-modal-submit').click();

        // Hover over the Tile Selection tab and drag Proposed Schedule to the layout
        cy.get('.mdi-developer-board').trigger('mouseover');
        cy.get('#dragtile-proposed-schedule-timeline-tile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-proposed-schedule-timeline-tile > .info-border').trigger('mouseup', {force:true});

        // Select target view
        cy.get('.resource-display-mode-target').click();

        // C105-F20 test: Verify associated tasks displayed
        // Select and confirm ES task is on timeline
        let numAttempts = 30;
        waitForTaskTooltip(targetId1, numAttempts); // Wait for tooltip to open, ES task is assigned to target 1
        cy.get('#EA-details > td').should((value) => {
            expect(value).to.contain(esTaskType);
        })

        // Select and confirm EA task is on timeline
        waitForTaskTooltip(targetId2, numAttempts); // Wait for tooltip to open, EA task is assigned to target 2
        cy.contains('td', eaTaskName);

        // C105-F21 test: Verify associated tasks displayed are cancelled
        let currentTime = new Date().toISOString();

        // Get ES task
        cy.request({
            method: 'GET',
            url: sew_task_url + '/' + esTaskId
        })
        .then((response) => {
            // Update ES task with cancelled state
            let cancelEsSewTask = response.body;
            cancelEsSewTask.schedState = 'PROPOSED_CANCEL';
            cancelEsSewTask.execStatus = {};
            cancelEsSewTask.execStatus.taskingGroupId = esTaskId;
            cancelEsSewTask.execStatus.timestamp = currentTime;
            cancelEsSewTask.execStatus.execState = 'EXECUTING';

            cy.request({
                method: 'PUT',
                url: sew_task_url,
                body: cancelEsSewTask
            })
            .then((response) => {
                expect(response.status).to.eq(statusCode)
            })
        })

        // Get EA task
        cy.request({
            method: 'GET',
            url: sew_task_url + '/' + eaTaskId
        })
        .then((response) => {
            // Update EA task with cancelled state
            let cancelEaSewTask = response.body;
            cancelEaSewTask.schedState = 'PROPOSED_CANCEL';
            cancelEaSewTask.execStatus = {};
            cancelEaSewTask.execStatus.taskingGroupId = eaTaskId;
            cancelEaSewTask.execStatus.timestamp = currentTime;
            cancelEaSewTask.execStatus.execState = 'EXECUTING';

            cy.request({
                method: 'PUT',
                url: sew_task_url,
                body: cancelEaSewTask
            })
            .then((response) => {
                expect(response.status).to.eq(statusCode)
            })
        })

        // Select and confirm ES task is cancelled
        let cancelState = 'Proposed Cancel';
        waitForTaskTooltip(targetId1, numAttempts); // Wait for tooltip to open, ES task is assigned to target 1
        cy.contains('td', cancelState, {timeout: 10000});

        // Select and confirm EA task is cancelled
        waitForTaskTooltip(targetId2, numAttempts); // Wait for tooltip to open, EA task is assigned to target 2
        cy.contains('td', cancelState, {timeout: 10000});

        // C105-F22 test: Verify associated tasks displayed with target data updates
        // Get ES task
        cy.request({
            method: 'GET',
            url: sew_task_url + '/' + esTaskId
        })
        .then((response) => {
            // Update ES task with updated target data
            let esSewTask = response.body;
            esSewTask.targetDetails.targetName = targetId2; // Assign task to target 2

            cy.request({
                method: 'PUT',
                url: sew_task_url,
                body: esSewTask
            })
            .then((response) => {
                expect(response.status).to.eq(statusCode)
            })
        })

        // Get EA task
        cy.request({
            method: 'GET',
            url: sew_task_url + '/' + eaTaskId
        })
        .then((response) => {
            // Update EA task with updated target data
            let eaSewTask = response.body;
            eaSewTask.targetDetails.targetName = targetId1; // Assign task to target 1

            cy.request({
                method: 'PUT',
                url: sew_task_url,
                body: eaSewTask
            })
            .then((response) => {
                expect(response.status).to.eq(statusCode)
            })
        })

        // Select and confirm ES task is assigned to target 2
        waitForTaskTooltip(targetId2, numAttempts); // Wait for tooltip to open
        cy.get('#EA-details > td').should((value) => {
            expect(value).to.contain(esTaskType);
        })

        // Select and confirm ES task is assigned to target 1
        waitForTaskTooltip(targetId1, numAttempts); // Wait for tooltip to open
        cy.contains('td', eaTaskName);
    })
})

// Select timeline entry until tooltip appears
function waitForTaskTooltip(targetId, numAttempts) {
    if (numAttempts <= 0) {
        return;
    }
    
    cy.get('#' + targetId + ' > .TimelineRowSetLabelDiv').click(700, 15, {force: true});
    cy.get('#' + 'TimelineGantt').then(($timeline) => {
        if ($timeline.children().length != 4)
            {
                cy.wait(1000);
                waitForTaskTooltip(targetId, numAttempts - 1);
            }
    });
}
