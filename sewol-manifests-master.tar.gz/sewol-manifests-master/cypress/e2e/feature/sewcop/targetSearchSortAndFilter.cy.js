/***********************************************************************************************************************
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 * 
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 * 
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 * 
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import '@4tw/cypress-drag-drop'

describe('Search, Sort, and Filter Capabilities for Targets', () => {
  
  // C064-F07
  // C064-F11
  // C064-F12
  it('Check Target search, sort and filter', () => {

    cy.login('Xavier')
 
    cy.fixture('seit/mars_attacks_es_target_data').then((targetdata) => {

      // Ingest C21000 arget data to repository
      let soiDesignator1 = targetdata[0].soiDesignator;
      cy.request({
        method: 'POST',
        url: 'repository/targetData',
        body: targetdata[0]
      }).then((resp) => {
        expect(resp.status).to.equals(200)
      })

      // Ingest C21001 arget data to repository
      let soiDesignator2 = targetdata[1].soiDesignator;
      cy.request({
        method: 'POST',
        url: 'repository/targetData',
        body: targetdata[1]
      }).then((resp) => {
        expect(resp.status).to.equals(200)
      })

      cy.visit({
        url: '/',
        failOnStatusCode: false
      });

      // Select the role from the RTiles display
      cy.get('#role-select-modal-prompt-option').select('SEW_OPERATOR');
      cy.get('#role-select-modal-submit').click();

      // Hover over the Tile Selection tab and drag Mission Folders to the layout
      cy.get('.mdi-developer-board').trigger('mouseover');

      cy.get('#dragtile-case-folder-tile > .info-border').drag('.lm_goldenlayout', {force:true})
      cy.get('#dragtile-case-folder-tile > .info-border').trigger('mouseup', {force:true});

      // Wait for the Mission Folders to be populated on the screen, by verifying
      // that the folder tabs are visible.
      cy.get('.cf-tabs-list').should('be.visible');

      // Select the All folder
      cy.get('.ui-tabs-anchor > .caseFolderName').contains('All').click();

      // Select List View
      cy.get('#theLayoutContainer').find('span.btn.btn-sm.btn-default.mdi.mdi-view-headline.list-view-button').click();

      // Sort items by 'Name' in ascending order
      cy.get('#data-table-All_wrapper > div.dataTables_scroll > div.dataTables_scrollHead').find('thead').click();

      const valuesArray = []

      // Verify we have items in the table
      cy.get('#data-table-All > tbody').should('have.descendants', 'td.dtr-control.sorting_1');

      // Check table items are sorted in ascending order
      cy.get('#data-table-All > tbody').find('td.dtr-control.sorting_1').each(($element) => {
        const textValue = $element.text().trim();
        // Populate array of table items
        valuesArray.push(textValue);
      }).then(() => {
        // Verify sort
        cy.wrap(valuesArray).should('satisfy', isAscending)
      });

      // Enter 'TARGET' in the filter box
      cy.get('#data-table-All_filter').find('input[type=search]').should('not.be.disabled').type('TARGET');

      // Check that only TARGET data is displayed
      // Verify filter
      cy.get('#data-table-All').find('tbody').find('tr').each(($element) => {
        cy.wrap($element.find(':nth-child(2)')).should('contain', 'Target')
      });

      // Switch to Card View
      cy.get('#theLayoutContainer').find('span.btn.btn-sm.btn-default.mdi.mdi-view-module.object-view-button').click();

      // Get the data-id of the C21000 trget brief card
      cy.get('[data-type="TARGET"][data-objname="' + soiDesignator1 + '"]').invoke('attr', 'data-id').then((idValue) =>  {

        // Add testFolder
        const folderName='testFolder-' + crypto.randomUUID();
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('input.form-control.case-folder-add').type(folderName);
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('i.mdi.mdi-plus').click();

        // Go to testFolder
        cy.get('a[href*="' + folderName + '"]').click();

        // Search for TARGET with ID from the 'All' folder
        cy.get('[name=entityTypeDropdown]').select('TARGET');
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('input.form-control.cfobj-search').type(idValue);
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('span.cfobj-searchbar-addto-folder.mdi.mdi-folder-plus').click();
        cy.get('#add-to-folder-menu').find('a:contains(' + folderName + ')').click();

        // Check found TARGET is displayed in the testFolder
        // Verify search
        cy.get('#' + folderName + '-card-panel').find('div.brief-card.target-type.asset').should('exist');
        cy.get('#' + folderName + '-card-panel').find('div.brief-card.target-type.asset').invoke('attr', 'data-id').should('equal', idValue);

        // Clear the searchbox
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('input.form-control.cfobj-search').clear();
 
        // Search for invalid text
        cy.get('[name=entityTypeDropdown]').select('TARGET');
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('input.form-control.cfobj-search').type('! this is not a target ^');
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('span.cfobj-searchbar-addto-folder.mdi.mdi-folder-plus').click();
        cy.get('#add-to-folder-menu').find('a:contains(' + folderName + ')').click();

        // Check invalid text produces an error
        cy.get('#gritter-item-1').find('span.gritter-title').should('contain.text', 'ERROR');

        // Clear the searchbox
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('input.form-control.cfobj-search').clear();

        // Clear the add folder text box.
        cy.get('#theLayoutContainer').find('div.controlsContainer').find('input.form-control.case-folder-add').clear();

        // Remove testFolder
        cy.get('a[href*="' + folderName + '"]').siblings('.removeCF').click();

        // Delete the C21000 target from the repository
        cy.request({
          method: 'DELETE',
          url: 'repository/targetData/' + soiDesignator1
        }).then((resp) => {
          expect(resp.status).to.equals(200)
        })

        // Delete the C21001 target from the repository
        cy.request({
          method: 'DELETE',
          url: 'repository/targetData/' + soiDesignator2
        }).then((resp) => {
          expect(resp.status).to.equals(200)
        })

        cy.logout('Xavier')
      });
    });
  });
});

function isAscending(arr) {
  return arr.every(function (x, i) { 
    return i === 0 || x.toLowerCase() >= arr[i - 1].toLowerCase();  
  }); 
}
