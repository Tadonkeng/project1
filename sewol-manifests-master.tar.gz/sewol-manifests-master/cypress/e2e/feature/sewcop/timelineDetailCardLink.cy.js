/***********************************************************************************************************************
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 * 
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 * 
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 * 
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import '@4tw/cypress-drag-drop'

describe('SEWCOP Display', () => {
 
  // CAP-122
  it('Entity Details from Timeline', () => {

    // Ingest C21000 target data to repository
    cy.fixture('seit/mars_attacks_es_target_data').then((targetdata) => {
      let soiDesignator = targetdata[0].soiDesignator;
      cy.request({
        method: 'POST',
        url: 'repository/targetData',
        body: targetdata[0]
      });

      const rmtId = "RMT-9";

      // Add and start RMT
      cy.coiRmtSimAdd(rmtId)
      cy.coiRmtSimStart(rmtId)

      // Send startup event message
      cy.coiRmtSimStartUpEvent(rmtId);

      // Log in as Xavier as the SEW_OPERATOR role
      cy.sewcopSelectRole('SEW_OPERATOR');
      
      // Make sure rtiles layout has loaded before proceeding
      cy.get('#page-container').should('be.visible');

      // Drag the execution schedule to the layout
      cy.sewcopAddTile('executionschedule');

      // Defaults to sew system view, first double click on a sew system resource to open the detail card
      cy.get(`#${rmtId} > div > span`).dblclick();
      
      // Verify C122-F01
      cy.get('[id="bbcard-title"]').should(
        "have.text",
        `${rmtId}`
      );
      
      // Close the detail card
      cy.get('.close-modal-bbcard').click()

      // Select the Targets tab on the Execution Schedule
      cy.get("#theLayoutContainer").find("li.resource-display-mode-target.nav-item").click();

      // Double click on a target resource to open the detail card
      cy.get(`#${soiDesignator} > div > span`).dblclick();
      
      // Verify C122-F03
      cy.get('[id="bbcard-title"]').should(
        "have.text",
        `${soiDesignator}`
      );

      // Close the detail card
      cy.get('.close-modal-bbcard').click()

      // Close the execution schedule
      cy.sewcopCloseTile();

      // Drag the proposed schedule to the layout
      cy.sewcopAddTile('proposedschedule');

      // Defaults to sew system view, first double click on a sew system resource to open the detail card
      cy.get(`#${rmtId} > div > span`).dblclick();
      
      // Verify C122-F02
      cy.get('[id="bbcard-title"]').should(
        "have.text",
        `${rmtId}`
      );
      
      // Close the detail card
      cy.get('.close-modal-bbcard').click()

      // Switch to target view on the timeline
      cy.get("#theLayoutContainer").find("li.resource-display-mode-target.nav-item").click();
      
      //Double click on a target resource to open the detail card
      cy.get(`#${soiDesignator} > div > span`).dblclick();
      
      // Verify C122-F03
      cy.get('[id="bbcard-title"]').should(
        "have.text",
        `${soiDesignator}`
      );

      // Close the detail card
      cy.get('.close-modal-bbcard').click()

      // Close the proposed schedule
      cy.sewcopCloseTile();

      // Delete the C21000 target from the repository
      cy.request({
        method: 'DELETE',
        url: 'repository/targetData/' + soiDesignator
      })

      cy.logout('Xavier')

      // Delete the RMT from the sim
      cy.coiRmtSimDelete(rmtId)
    })
  })
})
