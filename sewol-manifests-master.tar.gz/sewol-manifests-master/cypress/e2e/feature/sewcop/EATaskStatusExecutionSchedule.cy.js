/***********************************************************************************************************************
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 * 
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 * 
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 * 
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import '@4tw/cypress-drag-drop'

// Variables
let user = 'Xavier';
let user_role = 'SEW_OPERATOR';
let sew_task_url = '/data-service/sewTask';
let sew_capability_url = '/data-service/sewol/sewSystemCapabilities';
let target_url = '/repository/targetData';
let statusCode = 200;
let rmtId = 'RMT-' + ('' + (Math.random() * 10)).replace('.', '');
let targetId = 'Target-' + crypto.randomUUID();
let taskId = crypto.randomUUID();
let taskName = 'EA Task Test';
let eaTaskType = 'ES_EA'; // For PI4
let currentTime = new Date();

// SEWCOP E2E test for CAP-107
describe('SEWCOP Display EA/ES Task', () => {
    // Execute before test
    before(() => {
        // Create RMT
        cy.coiRmtSimStart(rmtId);
        cy.coiRmtSimStartUpEvent(rmtId);
        cy.wait(10000); // RMTs take longer to post

        // Create target
        cy.fixture('seit/mars_attacks_es_target_data').then((targetData) => {
            let target = targetData[0];
            target.soiDesignator = targetId;
            target.uplink.satellite = '1';
            cy.request({
                method: 'POST',
                url: target_url,
                body: target
            })
            .then((response) => {
                expect(response.status).to.equals(statusCode)
            })
        })

        // Get SEW ID
        cy.request({
            method: 'GET',
            url: sew_capability_url
        })
        .then((response) => {
            let sewId = '';
            response.body.forEach((sewCapability) => {
                if (sewCapability.sewSystemName == rmtId) {
                    sewId = sewCapability.sewSystemUuid;
                }
            })

            // Get SEW task json
            cy.fixture('sewcop/SewTaskExample1.json').then((sewTaskJson) => {
                // Create new ES_EA SEW task
                let eaSewTask = sewTaskJson;
                eaSewTask.schedState = 'APPROVED';
                eaSewTask.startTime = currentTime.toISOString();
                let endTime = currentTime;
                let hours = 15 * 60 * 60 * 1000; // 1 hours in milliseconds
                endTime.setTime(currentTime.getTime() + hours); // Task ends after 15 hours
                eaSewTask.endTime = endTime.toISOString();

                // Set execution status
                eaSewTask.execStatus = {};
                eaSewTask.execStatus.timestamp = currentTime.toISOString();
                eaSewTask.execStatus.execState = 'ISSUED_TO_SEW'; // Set execution state to issued to SEW
                eaSewTask.execStatus.taskingGroupId = taskId;

                // Assign to SEW and target
                eaSewTask.sewSystemUuid = sewId;
                eaSewTask.sewSystemName = rmtId;
                eaSewTask.taskingGroupId = taskId;
                eaSewTask.taskName = taskName;
                eaSewTask.taskType = eaTaskType;
                eaSewTask.targetDetails.targetName = targetId;

                // Set mission status
                eaSewTask.missionStatus[0] = {};
                eaSewTask.missionStatus[0].taskingGroupId = taskId;
                eaSewTask.missionStatus[0].timestamp = currentTime.toISOString();
                let eaTaskId = crypto.randomUUID();
                eaSewTask.missionStatus[0].eaTaskId = eaTaskId;
                eaSewTask.missionStatus[0].missionState = 'ACTIVE'; // EA active
                let transmitterId = crypto.randomUUID();
                eaSewTask.missionStatus[0].transmitterId = transmitterId.toString();
                let esTaskId = crypto.randomUUID();
                eaSewTask.missionStatus[0].esTaskId = esTaskId;

                // Set TTP details
                eaSewTask.ttpTaskDetails[0] = {};
                eaSewTask.ttpTaskDetails[0].eaTaskId = eaTaskId;
                eaSewTask.ttpTaskDetails[0].techniqueName = 'Test';
                eaSewTask.ttpTaskDetails[0].transmitterId = transmitterId;
                eaSewTask.ttpTaskDetails[0].startWhen = 'START_TIME';

                cy.request({
                    method: 'POST',
                    url: sew_task_url,
                    body: eaSewTask
                })
                .then((response) => {
                    expect(response.status).to.eq(statusCode)
                })
            })
        })

        // Login with permissions
        cy.login(user);
    })

    // Execute after test
    after(() => {
        // Delete SEW task
        cy.request({
            method: 'DELETE',
            url: sew_task_url + '/' + taskId
        })
        .then((response) => {
            expect(response.status).to.eq(statusCode)
        })

        // Delete RMT
        cy.coiRmtSimDelete(rmtId);

        // Delete target
        cy.request({
            method: 'DELETE',
            url: target_url + '/' + targetId
        })
        .then((response) => {
            expect(response.status).to.equals(statusCode)
        })

        // Logout
        cy.logout(user);
    })

    // Test ES/EA SEW task changes on execution schedule
    it('Updates on Execution Schedule', () => {
        // Visit Rtiles
        cy.visit({
            url: '/',
            failOnStatusCode: false
        });

        // Select the role from the RTiles display
        cy.get('#role-select-modal-prompt-option').select(user_role);
        cy.get('#role-select-modal-submit').click();

        // Hover over the Tile Selection tab and drag Execution Schedule to the layout
        cy.get('.mdi-developer-board').trigger('mouseover');
        cy.get('#dragtile-execution-schedule-timeline-tile > .info-border').drag('.lm_goldenlayout', {force:true})
        cy.get('#dragtile-execution-schedule-timeline-tile > .info-border').trigger('mouseup', {force:true});

        // Select target view
        cy.get('.resource-display-mode-target').click();

        // C107-F10 test: Verify associated task displayed has EA task status
        // Select and confirm SEW task has EA active on timeline
        let numAttempts = 30;
        waitForTaskTooltip(numAttempts); // Wait for tooltip to open

        let eaActive = 'EA-001: Active';
        cy.contains('td', eaActive);

        let issuedSewState = 'Issued to SEW';
        cy.contains('td', issuedSewState);

        // C107-F11 test: Verify associated SEW task EA task status has changed
        // Get SEW task
        cy.request({
            method: 'GET',
            url: sew_task_url + '/' + taskId
        })
        .then((response) => {
            // Update SEW task with an inactive EA task
            let eaSewTask = response.body;
            eaSewTask.execStatus.execState = 'EXECUTING'; // Set execution state to executing
            eaSewTask.missionStatus[0].missionState = 'INACTIVE';

            cy.request({
                method: 'PUT',
                url: sew_task_url,
                body: eaSewTask
            })
            .then((response) => {
                expect(response.status).to.eq(statusCode)
            })
        })

        // Select and confirm EA task status is no longer active
        cy.contains('td', eaActive, {timeout: 10000}).should('not.exist');
        let executeState = 'Executing';
        cy.contains('td', executeState);

        // C107-F12 test: Verify associated task stop time has updated
        // Get SEW task
        cy.request({
            method: 'GET',
            url: sew_task_url + '/' + taskId
        })
        .then((response) => {
            // Update SEW task with new stop time 
            let eaSewTask = response.body;
            let newTime = new Date();
            newTime.setDate(currentTime.getDate() + 1); // Set new time to 1 day
            newTime = newTime.toISOString();
            eaSewTask.endTime = newTime;
            eaSewTask.execStatus.execState = 'COMPLETE'; // Set execution state to complete

            cy.request({
                method: 'PUT',
                url: sew_task_url,
                body: eaSewTask
            })
            .then((response) => {
                expect(response.status).to.eq(statusCode)
            })

            // Select and confirm SEW task has new stop time
            let stopTimeStr = 'Stop: ' + newTime.slice(11, 16) + 'Z'; // Get hours and minutes
            cy.contains('td', stopTimeStr, {timeout: 10000});
            let completeState = 'Complete';
            cy.contains('td', completeState);

            // Restart task with ES trigger
            cy.request({
                method: 'GET',
                url: sew_task_url + '/' + taskId
            })
            .then((response) => {
                // Update SEW task with new stop time 
                let eaSewTask = response.body;
                eaSewTask.execStatus.execState = 'EXECUTING'; // Set execution state to executing
                eaSewTask.ttpTaskDetails[0].startWhen = 'ES_TRIGGER'; // Set ES trigger
                eaSewTask.missionStatus[0].missionState = 'ACTIVE'; // Set EA task to active
    
                cy.request({
                    method: 'PUT',
                    url: sew_task_url,
                    body: eaSewTask
                })
                .then((response) => {
                    expect(response.status).to.eq(statusCode)
                })
            })

            // Select and confirm SEW task has EA active ES triggered on timeline
            let esTrigger = 'EA-001: Triggered';
            cy.contains('td', esTrigger + ' Active', {timeout: 10000});

            // Update EA task to inactive with ES trigger
            cy.request({
                method: 'GET',
                url: sew_task_url + '/' + taskId
            })
            .then((response) => {
                // Update SEW task with new stop time 
                let eaSewTask = response.body;
                eaSewTask.missionStatus[0].missionState = 'INACTIVE'; // Set EA task to inactive
    
                cy.request({
                    method: 'PUT',
                    url: sew_task_url,
                    body: eaSewTask
                })
                .then((response) => {
                    expect(response.status).to.eq(statusCode)
                })
            })

            // Select and confirm SEW task has EA inactive ES triggered on timeline
            cy.contains('td', esTrigger, {timeout: 10000});
        })
    })
})

// Select timeline entry until tooltip appears
function waitForTaskTooltip(numAttempts) {
    if (numAttempts <= 0) {
        return;
    }
    
    cy.get('#' + targetId + ' > .TimelineRowSetLabelDiv').click(650, 15, {force: true});
    cy.get('#' + 'TimelineGantt').then(($timeline) => {
        if ($timeline.children().length != 4)
            {
                cy.wait(1000);
                waitForTaskTooltip(numAttempts - 1);
            }
    });
}
