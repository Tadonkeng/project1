/***********************************************************************************************************************
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 * 
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 * 
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 * 
 * Violations are subject to severe criminal penalties.
 **********************************************************************************************************************/
import '@4tw/cypress-drag-drop'

describe('Entity Folder Test', () => {
 
  // C048-F01
  it('creates an entity folder and adds entities to it', () => {

      const rmtId = "RMT-9";

      // Add and start RMT
      cy.coiRmtSimAdd(rmtId)
      cy.coiRmtSimStart(rmtId)

      // Send event message
      cy.coiRmtSimStartUpEvent(rmtId);

      // allow time for event to process before running next test which verifies
      cy.wait(5000);

      cy.login('Xavier');

      // Ingest C21000 target data to repository
      cy.fixture('seit/mars_attacks_es_target_data').then((targetdata) => {
        let soiDesignator = targetdata[0].soiDesignator;
        cy.request({
          method: 'POST',
          url: 'repository/targetData',
          body: targetdata[0]
        }).then((resp) => {
          expect(resp.status).to.equals(200)
        })
  
      cy.visit({
        url: '/',
        failOnStatusCode: false
      });

      // Select the role from the RTiles display
      cy.get('#role-select-modal-prompt-option').select('SEW_OPERATOR');
      cy.get('#role-select-modal-submit').click();

      // Hover over the Tile Selection tab and drag Mission Folders to the layout
      cy.get('.mdi-developer-board').trigger('mouseover');

      cy.get('#dragtile-case-folder-tile > .info-border').drag('.lm_goldenlayout', {force:true})
      cy.get('#dragtile-case-folder-tile > .info-border').trigger('mouseup', {force:true});

      // Wait for the Mission Folders to be populated on the screen, by verifying
      // that the folder tabs are visible.
      cy.get('.cf-tabs-list').should('be.visible');

      // Create entity folder
      const folderName='newMissionFolder-' + crypto.randomUUID();
      cy.get('.case-folder-add').type(folderName);
      cy.get('.special-input > .mdi').click();

      // Add entities from All to the new folder, start by selecting the All folder
      cy.get('.ui-tabs-anchor > .caseFolderName').contains('All').click();

      // Click on the Target brief card in the All folder to add it to the new folder
      cy.get('#All-card-panel')
        .find('[data-type="TARGET"][data-objname="' + soiDesignator + '"]')
        .siblings('.brief-top-right')
        .find('.brief-addto-folder')
        .click(); 

      cy.get('.add-to-folder-menu-options').children().contains(folderName).click();

      // Click on the SEW brief card in the All folder to add it to the new folder
      cy.get('#All-card-panel')
        .find('[data-type="SEWSYSTEM"][data-objname="' + rmtId + '"]')
        .siblings('.brief-top-right')
        .find('.brief-addto-folder')
        .click(); 

      cy.get('.add-to-folder-menu-options').children().contains(folderName).click();

      cy.get('.caseFolderName').contains(folderName).click();
      // Check that there are 2 entities in the new folder
      cy.get('#' + folderName + '-card-panel').children().should('have.length', 2);
      cy.screenshot('MissionFolderCreated')

      // Delete the newly created folder
      cy.contains(folderName).siblings('.removeCF').click();
      cy.screenshot('MissionFolderDeleted')

      // Delete the RMT from the sim
      cy.coiRmtSimDelete(rmtId)

      // Delete the C21000 target from the repository
      cy.request({
        method: 'DELETE',
        url: 'repository/targetData/' + soiDesignator
      }).then((resp) => {
        expect(resp.status).to.equals(200)
      })

      cy.logout('Xavier')
    })
  })
})
