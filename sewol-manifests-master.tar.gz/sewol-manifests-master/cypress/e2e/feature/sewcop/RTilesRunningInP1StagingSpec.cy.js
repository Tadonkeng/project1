/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

import '@4tw/cypress-drag-drop'

describe('Loads RTiles and displays Mission folders', () => {

  // C033-F01
  it('loads RTiles in staging and opens Mission Folders tile', () => {

    cy.login('Xavier');

    cy.visit({
      url: 'rtiles/',
      failOnStatusCode: false
    });

    // Select the role from the RTiles display
    cy.get('#role-select-modal-prompt-option').select('SEW_OPERATOR');
    cy.get('#role-select-modal-submit').click();

    // Hover over the Tile Selection tab and drag Mission Folders to the layout
    cy.get('.mdi-developer-board').trigger('mouseover');

    cy.get('#dragtile-case-folder-tile > .info-border').drag('.lm_goldenlayout', {force:true})
    cy.get('#dragtile-case-folder-tile > .info-border').trigger('mouseup', {force:true});

    // Wait for the Mission Folders to be populated on the screen, by verifying
    // that the folder tabs are visible.
    cy.get('.cf-tabs-list').should('be.visible');
    cy.screenshot('RTilesRunning');

    cy.logout('Xavier');
  })
})
