/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

describe("COI", () => {
    it('Ingest MVCR SEW System Capabilities', () => {
        const SUCCESS_STATUS = 200
        const TEST_RMT = "RMT-18"

        // Future time for startup event
        var fiveMinutesFromNow = new Date(Date.now() + 5 * 60000).toISOString()

        // Add and start RMT
        cy.coiRmtSimAdd(TEST_RMT)
        cy.coiRmtSimStart(TEST_RMT)

        // Travis has TRAINER role
        const rbacUser = 'Travis'
        cy.login(rbacUser)
        
        //Send event message
        cy.login('Travis').then(() => {
            cy.request({
                method: 'POST',
                url: `/coi-rmt-simulator/event/`,
                body:
                {
                    "eventType": "StartUpEvent",
                    "rmtId": TEST_RMT,
                    "message": "{ \"capabilities\": { \"system_id\": \"" + TEST_RMT + "\", \"location\": { \"latitude\": 38.9823, \"longitude\": -77.4384, \"altitude\": 89.92 }, \"timing_source\": { \"name\": \"Timing Source Test name\", \"role\": \"PRIMARY\", \"source_type\": \"SERVER\", \"stratum\": 1, \"status\": \"SYNCED\" }, \"antennas\": [], \"receiver_channels\": [], \"transmit_channels\": null, \"software\": [], \"ea_capable\": false, \"supported_ttps\": [], \"reporting_mode\": \"NORMAL\", \"pdu_name_to_port_map\": [], \"total_memory\": null, \"cpu_details\": null, \"num_processors\": null, \"cpu_megahertz\": null }, \"bitResults\": { \"status\": false, \"faults\": [] } }",
                    "simulationTime": fiveMinutesFromNow
                }
            })
                .then((resp) => {
                    expect(resp.status).to.equals(SUCCESS_STATUS)
                })
        }).then(() => {
            cy.logout('Travis');
        })

        // allow time for event to process before running next test which verifies
        cy.wait(5000);

        //Verify Sew System Capabilites are saved in Repository 
        // Adam has ADMINISTRATOR role
        cy.login('Adam')
        cy.request({
            method: 'GET',
            url: `/data-service/sewol/sewSystemCapabilities`
        })
            .then((resp) => {
                expect(resp.status).to.equals(SUCCESS_STATUS)
                expect(JSON.stringify(resp.body)).to.contain(TEST_RMT)
            })
        cy.logout('Adam') 

        // Clean up
        cy.coiRmtSimDelete(TEST_RMT)
        cy.logout(rbacUser) 
    })
})
