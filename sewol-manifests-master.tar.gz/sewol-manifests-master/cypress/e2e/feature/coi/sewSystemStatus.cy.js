/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

describe("COI", () => {
  it("Ingest MVCR SEW System Status", () => {
    const testRmtId = "RMT-15IngestMvcrSewSystemStatus";

    // Add and start RMT
    cy.coiRmtSimAdd(testRmtId);
    cy.wait(5000); // Allow time for the RMT to be added

    cy.coiRmtSimStart(testRmtId);
    cy.wait(5000); // Allow time for the RMT to start

    const simulationTime = new Date(Date.now() - 10000).toISOString();

    const rbacUser = 'Travis'
    cy.login(rbacUser)

    // Trigger a Startup Event for the RMT
    cy.login('Travis').then(() => {
      cy.request({
        method: 'POST',
        url: `/coi-rmt-simulator/event/`,
        body: {
          "eventType": "StartUpEvent",
          "rmtId": testRmtId,
          "message": JSON.stringify({
            "capabilities": { "system_id": testRmtId, "location": { "latitude": 38.9823, "longitude": -77.4384, "altitude": 89.92 }, "timing_source": { "name": "Timing Source Test name", "role": "PRIMARY", "source_type": "SERVER", "stratum": 1, "status": "SYNCED" }, "antennas": [], "receiver_channels": [], "transmit_channels": null, "software": [], "ea_capable": false, "supported_ttps": [], "reporting_mode": "NORMAL", "pdu_name_to_port_map": [], "total_memory": null, "cpu_details": null, "num_processors": null, "cpu_megahertz": null }, "bitResults": { "status": false, "faults": [] } ,
          }),
          "simulationTime": simulationTime
        }
      },
      )
      .then((resp) => {
      expect(resp.status).to.eq(200);
    }).then(() => {
      cy.logout('Travis');
    })

    cy.wait(35000)
    cy.login('Adam')
    cy.request({
      method: "GET",
      url: "data-service/sewol/sewSystemStatus",
      failOnStatusCode: false
    }).then((resp) => {
      expect(resp.status).to.equals(200);
        //Verify DS created SewSystemStatus by passing in the system name
      expect(JSON.stringify(resp.body)).contains(testRmtId)
    });
  });

  cy.logout(rbacUser)

  cy.wait(15000);

  // Clean up - Delete the RMT
    cy.coiRmtSimDelete(testRmtId);
  });
});
