/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

import SystemReset from "../../../fixtures/common/systemReset.js";

describe("COI", () => {
    it("Implement RBAC", () => {
        // Reset entire system before all feature tests
        cy.resetRmtSim();
        SystemReset.resetRepository();
        
        // ADD RMT
        const rmtId = "RMT-101";
        cy.coiRmtSimAdd(rmtId);
        // START RMT
        cy.coiRmtSimStart(rmtId);
        cy.wait(5000);
        //Check permissions
        cy.login('Adam')
        cy.request({
            method: "GET",
            url: "data-service/sewol/rmt",
            failOnStatusCode: false
        }).then((resp) => {
            expect(resp.status).to.equals(200);
            expect(JSON.stringify(resp.body)).to.contain(rmtId);
        });
        cy.logout('Adam')

        cy.wait(5000);

        // ADD RMT
        const rmtId2 = "RMT-201";
        cy.coiRmtSimAdd(rmtId2);
        // START RMT
        cy.coiRmtSimStart(rmtId2);
        cy.wait(5000)
        //Check permissions
        cy.login('Nancy')
        cy.request({
            method: "GET",
            url: "data-service/sewol/rmt",
            failOnStatusCode: false
        }).then((resp) => {
            expect(resp.status).to.equals(403);
        });
        cy.logout('Nancy')
    });
});
