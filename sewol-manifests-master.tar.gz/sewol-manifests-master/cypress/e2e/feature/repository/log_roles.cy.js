/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

// Cypress API tests for Roles
// Reads test data from fixtures
// This scenario is to test all the user roles
// <reference types ="Cypress" />

import MainMethods from '../../../fixtures/repository/mainMethods.js'
let urls = [
    '/data-service/sewol/auditLog/level/security',
    '/data-service/sewol/auditLog/level/activity',
    '/data-service/sewol/auditLog/level/opsdata',
]

let users = [
    { name: 'Adam', statuses: [200, 200, 403] },
    { name: 'Monica', statuses: [403, 403, 403] },
    { name: 'Charlie', statuses: [403, 403, 403] },
    { name: 'Sean', statuses: [403, 403, 403] },
    { name: 'Audrie', statuses: [200, 403, 403] },
    { name: 'Travis', statuses: [200, 200, 403] },
    { name: 'Oprah', statuses: [403, 403, 403] },
    { name: 'Mike', statuses: [403, 403, 403] },
]

it(`Repository Logging Display`, () => {
    for (let user of users) {
        cy.log(user.name)
        cy.login(user.name)
        for (let i = 0; i < 3; i++) {
            MainMethods.GetSimple('', urls[i], user.statuses[i])
            cy.get('@get_details').then((response) => {})
        }
        cy.logout(user.name)
    }
})
