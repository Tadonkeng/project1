/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

// Cypress API tests for Roles
// Reads test data from fixtures
// This scenario is to test all the user roles
// <reference types ="Cypress" />

import { post_endpoints } from '../../../fixtures/repository/targetdatainfo.json'
import { targetdata } from '../../../fixtures/repository/targetdatainfo.json'
import { updatedtargetdata } from '../../../fixtures/repository/targetdatainfo.json'
import { post_endpoint } from '../../../fixtures/repository/mto.json'
import { mto } from '../../../fixtures/repository/mto.json'
import { updatedmto } from '../../../fixtures/repository/mto.json'
import MainMethods from '../../../fixtures/repository/mainMethods.js'
import dayjs from 'dayjs'
import {
    approve_url,
    approve_body,
} from '../../../fixtures/repository/approve.json'

let users = [
    'Adam',
    'Monica',
    'Charlie',
    'Sean',
    'Audrie',
    'Travis',
    'Oprah',
    'Mike',
]

for (let target_endpoint of post_endpoints) {
    for (let user of users) {
        it(`Implement Tac C2 RBAC`, () => {
            let target_body = targetdata
            let put_body = updatedtargetdata
            let target_post_url = target_endpoint.post_url
            let target_get_url = target_endpoint.get_url
            let mto_body = mto
            let mto_put_body = updatedmto
            let mto_post_url = post_endpoint.post_url
            let mto_get_url = post_endpoint.get_url
            let fail = 403
            let ok = 200
            let err = 400

            let rand = Math.random() * 10000
            let number = Math.floor(rand)

            Object.assign(approve_body, { number: number })
            Object.assign(mto_body, { number: number })

            const time = dayjs().add(1, 'hour').format('DDHHmm')
            const today = dayjs().format('MMMYY')
            const plusTen = dayjs().add(10, 'day').format('DDHHmm')
            const monthsTen = dayjs().add(10, 'day').format('MMMYY')
            const together = time + 'Z' + today.toUpperCase()
            const togetherPlus = plusTen + 'Z' + monthsTen.toUpperCase()
            Object.assign(mto_body, { timestamp: together })
            Object.assign(mto_body, { periodStart: together })
            Object.assign(mto_body, { periodEnd: togetherPlus })
            Object.assign(mto_put_body, { timestamp: together })
            Object.assign(mto_put_body, { periodStart: together })
            Object.assign(mto_put_body, { periodEnd: togetherPlus })

            let p_code = fail
            let g_code = ok
            let a_code = fail

            cy.log(user)
            cy.login(user)

            if (user == 'Travis') {
                p_code = ok
                a_code = err
            }
            if (user == 'Oprah') {
                p_code = ok
            }
            if (user == 'Mike') {
                a_code = err
            }

            MainMethods.PostSimple(target_body, target_post_url, p_code)
            cy.get('@post_details').then((response) => {
                MainMethods.PostSimple(mto_body, mto_post_url, p_code)
                cy.get('@post_details').then((response) => {
                    MainMethods.PutSimple(
                        put_body,
                        target_post_url,
                        p_code
                    )
                    cy.get('@put_details').then((response) => {
                        MainMethods.PutSimple(
                            mto_put_body,
                            mto_post_url,
                            p_code
                        )
                        cy.get('@put_details').then((response) => {
                            MainMethods.PostSimple(
                                approve_body,
                                approve_url,
                                a_code
                            )
                            cy.get('@post_details').then((response) => {})
                            MainMethods.GetSimple(
                                target_body,
                                target_get_url,
                                g_code
                            )
                            cy.get('@get_details').then((response) => {})
                            MainMethods.GetSimple(
                                mto_body,
                                mto_get_url,
                                g_code
                            )
                            cy.get('@get_details').then((response) => {})
                        })
                    })
                })
            })

            cy.logout(user)
        })
    }
}
