/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

// Cypress API tests for Target Data API's
// Reads test data from targetdata.json in fixtures
// This scenario is to test all the Target Data end points.
// <reference types ="Cypress" />

import { post_endpoints } from '../../../fixtures/repository/targetdatainfo.json'
import { targetdata } from '../../../fixtures/repository/targetdatainfo.json'
import { updatedtargetdata } from '../../../fixtures/repository/targetdatainfo.json'
import { endpoints } from '../../../fixtures/repository/targetdatainfo.json'
import MainMethods from '../../../fixtures/repository/mainMethods.js'

//Generic API call tests, just expecting status code and text
//Old tests for UDL, commented out
// for (let endpoint of endpoints) {
//     //Cycle through the  permutations
//     it(`API Test for ${endpoint.name}`, () => {
//         cy.login('Adam')
//         MainMethods.ApiCall(endpoint.path, endpoint.method, endpoint.body)
//         //Validate status code and status text
//         cy.get('@details').its('status').should('eq', endpoint.code)
//         cy.get('@details').then((response) => {
//             expect(response.statusText).to.eq(endpoint.statusText)
//         })
//         cy.logout('Adam')
//     })
// }

//Post Get Put Delete
for (let post_endpoint of post_endpoints) {
    it(`Handle Target Data update (CAP-64)`, () => {
        cy.login('Travis')
        let body = targetdata
        let put_body = updatedtargetdata
        let post_url = post_endpoint.post_url
        let get_url = post_endpoint.get_url
        let put_url = post_endpoint.put_url
        let delete_url = post_endpoint.delete_url
        let satelliteID = targetdata.soiDesignator

        MainMethods.PostGetPutDeleteForTargetdata(
            body,
            put_body,
            post_url,
            get_url,
            put_url,
            delete_url,
            satelliteID
        )

        // Three sets of responses are gathered and verified below

        // verifying post data
        cy.get('@post_details').then((response) => {
            for (let verification of post_endpoint.verifications) {
                Object.keys(response.body).forEach(function (key) {
                    if (verification[key]) {
                        if (
                            key != 'targetAssociations' &&
                            key != 'uplink' &&
                            key != 'downlink'
                        ) {
                            expect(response.body[key]).to.eq(verification[key])
                        }
                    }
                })
            }
            cy.get('@get_details').then((get_response) => {
                for (let verification of post_endpoint.updatedverifications) {
                    Object.keys(get_response.body).forEach(function (key) {
                        if (verification[key]) {
                            if (
                                key != 'targetAssociations' &&
                                key != 'uplink' &&
                                key != 'downlink'
                            ) {
                                expect(get_response.body[key]).to.eq(
                                    verification[key]
                                )
                            }
                        }
                    })
                }

                cy.get('@put_details').then((put_response) => {
                    for (let verification of post_endpoint.updatedverifications) {
                        Object.keys(put_response.body).forEach(function (key) {
                            if (verification[key]) {
                                if (
                                    key != 'targetAssociations' &&
                                    key != 'uplink' &&
                                    key != 'downlink'
                                ) {
                                    expect(put_response.body[key]).to.eq(
                                        verification[key]
                                    )
                                }
                            }
                        })
                    }
                })
            })
        })

        //verify delete_details
        // cy.get('@delete_details').should('not.be.empty')
        cy.logout('Travis')
    })
}
