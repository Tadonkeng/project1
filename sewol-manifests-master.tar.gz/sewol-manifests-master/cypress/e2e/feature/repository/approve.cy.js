/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

// Cypress API tests for Approve flow
// Reads test data from fixtures
// <reference types ="Cypress" />

import { post_endpoints } from '../../../fixtures/repository/targetdatainfo.json'
import { targetdata } from '../../../fixtures/repository/targetdatainfo.json'
import { post_endpoint } from '../../../fixtures/repository/mto.json'
import { mto } from '../../../fixtures/repository/mto.json'
import MainMethods from '../../../fixtures/repository/mainMethods.js'
import {
    sew_url,
    mission_url,
    approve_url,
    approve_body,
    mission_plan,
} from '../../../fixtures/repository/approve.json'
import dayjs from 'dayjs'

//Post Get Put Delete

for (let target_endpoint of post_endpoints) {
    it(`CAP-096: Repository stores approved Tasks (CAP-96)`, () => {
        let user = 'Travis'
        let target_body = targetdata
        let target_post_url = target_endpoint.post_url
        let mto_post_url = post_endpoint.post_url
        let mto_body = mto
        let number = mto.number
        let fail = 403
        let ok = 200

        const time = dayjs().format('DDHHmm')
        const today = dayjs().format('MMMYY')
        const plusTen = dayjs().add(10, 'day').format('DDHHmm')
        const monthsTen = dayjs().add(10, 'day').format('MMMYY')
        const together = time + 'Z' + today.toUpperCase()
        const togetherPlus = plusTen + 'Z' + monthsTen.toUpperCase()

        let rand = Math.random() * 10000
        rand = Math.floor(rand)
        number = rand

        cy.login(user)

        Object.assign(approve_body, { number: number })
        Object.assign(mto_body, { number: number })
        Object.assign(mission_plan, { number: number })
        Object.assign(mission_plan.sewTasks[0], { missionNumber: number })
        Object.assign(mission_plan.sewTasks[1], { missionNumber: number })
        Object.assign(mto_body, { timestamp: together })
        Object.assign(mto_body, { periodStart: together })
        Object.assign(mto_body, { periodEnd: togetherPlus })
        Object.assign(mission_plan, { timestamp: together })
        Object.assign(mission_plan, { periodStart: together })
        Object.assign(mission_plan, { periodEnd: togetherPlus })

        MainMethods.PostSimple(target_body, target_post_url, ok)
        cy.get('@post_details').then((response) => {
            MainMethods.PostSimple(mto_body, mto_post_url, ok)
            cy.get('@post_details').then((response) => {
                cy.wait(5000) //Waiting for Sew Task
                MainMethods.GetSimple(approve_body, sew_url + number, ok)
                cy.get('@get_details').then((response) => {
                    MainMethods.PostSimple(mission_plan, mission_url, ok)
                    cy.get('@post_details').then((response) => {
                        cy.wait(2000)
                        MainMethods.GetSimple(
                            approve_body,
                            mission_url + '/' + number,
                            ok
                        )
                        cy.get('@get_details').then((response) => {
                            MainMethods.PostSimple(
                                approve_body,
                                approve_url,
                                ok
                            )
                            cy.get('@post_details').then((response) => {})
                        })
                    })
                })
            })
        })

        cy.logout(user)
    })
}
