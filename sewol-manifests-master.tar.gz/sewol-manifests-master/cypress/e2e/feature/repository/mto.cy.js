/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */

// Cypress API tests for MTO API's
// Reads test data from mto.json in fixtures
// This scenario is to test all the MTO end points.
// <reference types ="Cypress" />

import { post_endpoint } from '../../../fixtures/repository/mto.json'
import { mto } from '../../../fixtures/repository/mto.json'
import { updatedmto } from '../../../fixtures/repository/mto.json'
import MainMethods from '../../../fixtures/repository/mainMethods.js'
import dayjs from 'dayjs'

//Post Get Put Delete

it(`Validate Entered PI3 MTO (CAP-64)`, () => {
    cy.login('Travis')
    let body = mto
    let put_body = updatedmto
    let post_url = post_endpoint.post_url
    let get_url = post_endpoint.get_url
    let put_url = post_endpoint.put_url
    let delete_url = post_endpoint.delete_url
    let number = mto.number

    const time = dayjs().add(1, 'hour').format('DDHHmm')
    const today = dayjs().format('MMMYY')
    const plusTen = dayjs().add(10, 'day').format('DDHHmm')
    const monthsTen = dayjs().add(10, 'day').format('MMMYY')
    const together = time + 'Z' + today.toUpperCase()
    const togetherPlus = plusTen + 'Z' + monthsTen.toUpperCase()

    MainMethods.PostGetPutDeleteForMTO(
        body,
        put_body,
        post_url,
        get_url,
        put_url,
        delete_url + number,
        together,
        togetherPlus
    )

    // Three sets of responses are gathered and verified below

    // verifying post data
    cy.get('@post_details').then((response) => {
        for (let verification of post_endpoint.verifications) {
            Object.keys(response.body).forEach(function (key) {
                if (verification[key]) {
                    if (key == 'timestamp' || key == 'periodStart') {
                        expect(response.body[key]).to.eq(together)
                    } else {
                        if (key == 'periodEnd') {
                            expect(response.body[key]).to.eq(togetherPlus)
                        } else {
                            expect(response.body[key]).to.eq(verification[key])
                        }
                    }
                }
            })
        }
    })

    // verifying get data

    cy.get('@get_details').then((get_response) => {
        for (let verification of post_endpoint.verifications) {
            Object.keys(get_response.body).forEach(function (key) {
                if (verification[key]) {
                    if (key == 'timestamp' || key == 'periodStart') {
                        expect(get_response.body[key]).to.eq(together)
                    } else {
                        if (key == 'periodEnd') {
                            expect(get_response.body[key]).to.eq(togetherPlus)
                        } else {
                            expect(get_response.body[key]).to.eq(
                                verification[key]
                            )
                        }
                    }
                }
            })
        }
    })

    //verifying put data
    cy.get('@put_details').then((put_response) => {
        for (let verification of post_endpoint.updatedverifications) {
            Object.keys(put_response.body).forEach(function (key) {
                if (verification[key]) {
                    if (key == 'timestamp' || key == 'periodStart') {
                        expect(put_response.body[key]).to.eq(together)
                    } else {
                        if (key == 'periodEnd') {
                            expect(put_response.body[key]).to.eq(togetherPlus)
                        } else {
                            expect(put_response.body[key]).to.eq(
                                verification[key]
                            )
                        }
                    }
                }
            })
        }
    })

    //verify delete_details
    //cy.get('@delete_details').should('not.be.empty')
    cy.logout('Travis')
})
