/*
 * Copyright 2024 Raytheon Company, Northstrat Inc., CACI Inc. – Federal.
 * This software was developed pursuant to a Classified Contract Number with the U.S. Government.
 * The U.S. government's rights in and to this copyrighted software are as specified in
 * DFARS 252.227-7014 which was made part of the above contract.
 *
 * WARNING – This document or software contains Technical Data and / or technology whose export or disclosure to
 * Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22
 * C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).
 *
 * This document or software CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed
 * to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been
 * completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.
 *
 * Violations are subject to severe criminal penalties.
 */


import SystemReset from "../../fixtures/common/systemReset.js";
import * as timeConverter from "../../fixtures/common/timeConverter.js";

function replaceAllInJson(json,findString,replaceString) {
  let jsonString = JSON.stringify(json)
  jsonString = jsonString.replaceAll(findString,replaceString);
  return JSON.parse(jsonString)
}

//use BrainControl2001 target signal which is visible to RMT-8 
const targetIndex = 3;

describe("PI02", () => {

  it('RMT Capabilities Persistence', () => {
    //clear data
    cy.resetRmtSim();
    SystemReset.resetRepository();
    const rbacUser = 'Travis'
    const rmtId = "RMT-8";

    // Add and start RMT
    cy.coiRmtSimAdd(rmtId);
    cy.coiRmtSimStart(rmtId);
    cy.wait(1000); // Allow time for the RMT to start

    //Send event message
    cy.coiRmtSimStartUpEvent(rmtId);
    
    // Trigger a Heartbeat Event adn other nominal startups for the RMT
    rmtSimulatorNominalPeriodicEvents = [
      'HealthAndStatus',
      'HeartbeatEvent',
      'BITResultsEvent',
      'AntennaStatusEvent',
      'ReceiverTuneEvent'
    ]
    for (let periodicEventType of rmtSimulatorNominalPeriodicEvents) {
      cy.fixture('seit/rmt/' + periodicEventType).then((eventMessage) => {
        const rmtNum = rmtId.substring(4);
        eventMessage = replaceAllInJson(eventMessage,'RMTID',rmtId);
        eventMessage = replaceAllInJson(eventMessage,'RMTNUM',rmtNum);
        cy.coiRmtSimEvent({
          "eventType": periodicEventType,
          "rmtId": rmtId,
          "message": eventMessage,
          "delay": 1,
          "periodInSeconds": 10,
          "timestampSubstitutionToken": "TOBEREPLACED"
        });
      });
    }
    // allow time for event to process before running next test which verifies
    cy.wait(10000);

    //Verify Sew System Capabilites are saved in Repository and contain location data
    cy.login(rbacUser)
    cy.request({
      method: 'GET',
      url: 'data-service/sewol/sewSystemCapabilities',
      failOnStatusCode: false
    })
      .then((resp) => {
        expect(resp.status).to.equals(200)
        var sewSystemCataloged = 0
        for (let sewSystem of resp.body) {
          if (sewSystem.sewSystemName == rmtId) {
            sewSystemCataloged++
            expect(sewSystem.antennas[0].latitude).to.exist
            expect(sewSystem.antennas[0].longitude).to.exist
            expect(sewSystem.antennas[0].altitude).to.exist
          }
        }
        expect(sewSystemCataloged).to.not.equal(0)
      }
      )

    // log out
    cy.logout(rbacUser)
  })

  it('RMT Status Persistence', () => {

    //Triggers a Health and Status Event (Critical)
    const rbacUser = 'Travis'
    const rmtId = "RMT-8";

    cy.wait(20000); // Wait for periodic SEW status to be posted
    //Verify DS created SewSystemStatus with 'alive= true' by passing in the system name
    cy.login(rbacUser)
    cy.request({
      method: "GET",
      url: "data-service/sewol/sewSystemStatus",
      failOnStatusCode: false
    }).then((resp) => {
      expect(resp.status).to.equals(200)
      expect(JSON.stringify(resp.body)).to.include(rmtId);
      for (let rmtStatus of resp.body) {
        if (rmtStatus.sewSystemName == rmtId && rmtStatus.sewSystemName.databaseState == 'LATEST') {
          const recentStatusTime = Math.floor(Date.now() / 1000) - 10 // 10 seconds ago
          expect(rmtStatus.timestamp).to.be.greaterThan(recentStatusTime)
          expect(rmtStatus.alive).to.be(true)
        }
      }
    });
    cy.logout(rbacUser)

  })

  it('Target Info Storage/Retrieval (MVCR)', () => {
    const rbacUser = 'Sean'
    cy.login(rbacUser)
    //ingest target data to repository for BC2001
    cy.fixture('seit/mars_attacks_es_target_data.json').then((targetdata) => {
      const targetId = targetdata[targetIndex].soiDesignator;
      cy.request({
        method: 'POST',
        url: 'repository/targetData',
        body: targetdata[targetIndex],
      }).then((resp) => {
        expect(resp.status).to.equals(200)
      })

      cy.wait(10000)
      //verify data is stored in repository
      cy.request({
        method: 'GET',
        url: `repository/targetData/${targetId}`,
      })
        .then((resp) => {
          expect(resp.status).to.equals(200)
          expect(resp.body.soiDesignator).to.equals(`${targetId}`)
        })
      cy.logout(rbacUser)
    });
  })

  it('TLE UDL Retrieval and Storage/Internal Retrieval', () => {
    const rbacUser = 'Sean'
    cy.login(rbacUser)
    //verify udl data was populated into repository for ingestested target message
    cy.fixture('seit/mars_attacks_es_target_data.json').then((targetdata) => {
      const downlinkId = targetdata[targetIndex].downlink.satellite;
      cy.request({
        method: 'GET',
        url: `repository/udl/tles/${downlinkId}`,
      }).then((resp) => {
        var tle = JSON.parse(resp.body);
        expect(tle.idOnOrbit).to.equals(`${downlinkId}`)
      })
      cy.logout(rbacUser)
    })
  })

  it('MTO Manual Upload via REST API', () => {
    //MTO Splice and create tasks for BC2001
    cy.fixture('seit/mars_attacks_es_mto.json').then((mto) => {
      const rbacUser = 'Oprah'
      cy.login(rbacUser)
      var mtoname = mto.name
      // Update MTO timestamps for near future
      mtoTimestamp = Date.now() + (100000) //1.5 mins in the future
      mtoStart = mtoTimestamp + (300000) //5 mins in the future
      mtoEnd = mtoStart + (1200000) //20 mins in the future
      mto['timestamp'] = timeConverter.convertToMtoTime(mtoTimestamp)
      mto['periodStart'] = timeConverter.convertToMtoTime(mtoStart)
      mto['periodEnd'] = timeConverter.convertToMtoTime(mtoEnd)
      //remove all target tasks except for BC2001
      var newMissionTargets = []
      for (let missionTarget of mto['missionTargets']) {
        if (missionTarget.jiptlId == 'BrainControl2001') {
          newMissionTargets.push(missionTarget)
        }
      }
      mto['missionTargets'] = newMissionTargets

      //Upload MTO
      cy.request({
        method: 'POST',
        url: 'repository/sewol/missionTypeOrder',
        body: mto
      }).then((resp) => {
        expect(resp.status).to.equals(200)
      })

      cy.wait(10000)
      cy.logout(rbacUser)
    })
  })

  it('Tacc2 Generates Mission Schedule', () => {
    cy.fixture('seit/mars_attacks_es_mto.json').then((mto) => {
      var mtoname = mto.name
      //verify schedule and task data was generated and stored by Repository
      const rbacUser = 'Oprah'
      cy.login(rbacUser)
      cy.request({
        method: 'GET',
        url: 'data-service/missionPlan',
      }).then((resp) => {
        expect(resp.status).to.equals(200)
        var stoTaskExists = 0;
        for (var i = 0; i < resp.body.length; i++) {
          if (resp.body[i].name == mtoname) {
            for (var j = 0; j < resp.body[i].sewTasks.length; j++) {
              if (resp.body[i].sewTasks.length > 0) {
                stoTaskExists++
              }
            }
          }
        }
        expect(stoTaskExists).to.not.equal(0)
      })
      cy.logout(rbacUser)
    })
  })
})
