#!/bin/sh

aws --version

echo "Creating test file test.txt"
echo "This is a test file." > test.txt

export AWS_ACCESS_KEY_ID=$MINIO_ACCESS_KEY
export AWS_SECRET_ACCESS_KEY=$MINIO_SECRET_KEY

echo "Endpoint URL: $MINIO_ENDPOINT_URL"
echo "Bucket Name: $MINIO_BUCKET_NAME"
echo "Region: $MINIO_REGION"

echo "==================Initiate Test================="
aws s3 ls s3://$MINIO_BUCKET_NAME --endpoint-url $MINIO_ENDPOINT_URL --region $MINIO_REGION
aws s3 cp test.txt s3://$MINIO_BUCKET_NAME/test.txt --endpoint-url $MINIO_ENDPOINT_URL --region $MINIO_REGION
aws s3 cp s3://$MINIO_BUCKET_NAME/test.txt download_test.txt --endpoint-url $MINIO_ENDPOINT_URL --region $MINIO_REGION
cat download_test.txt
rm download_test.txt
aws s3 rm s3://$MINIO_BUCKET_NAME/test.txt --endpoint-url $MINIO_ENDPOINT_URL --region $MINIO_REGION
echo "==================Test Complete================="

echo "==================List Bucket contents================="
aws s3 ls s3://$MINIO_BUCKET_NAME --endpoint-url $MINIO_ENDPOINT_URL --region $MINIO_REGION --recursive
echo "=============List Bucket contents Complete============="
