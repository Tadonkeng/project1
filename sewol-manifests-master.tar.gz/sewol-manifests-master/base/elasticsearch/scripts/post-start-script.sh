#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

# make cwd the script dir
cd "$(dirname "$0")"

ES_URL="http://localhost:9200"

export LOG_FILE="/tmp/post-start/post-start.txt"

if [[ "${USE_MINIO}" = true || ${USE_MINIO} = "true" ]] ; then
  snapshot_repo_json_file="snapshot-repository.minio.json"
else
  snapshot_repo_json_file="snapshot-repository.json"
fi

echo "" > ${LOG_FILE}

# Wait for Elasticsearch to be ready
while [[ "$(curl -s -o /dev/null -w '%{http_code}' ${ES_URL}/_cluster/health)" != "200" ]]; do
  echo "Waiting for Elasticsearch to be ready..." >> ${LOG_FILE}
  sleep 5
done

# Run script commands after Elasticsearch is ready
echo "Elasticsearch is ready. Executing further actions." >> ${LOG_FILE}
# API calls to configure Elasticsearch here
printf "\nReloading security settings...\n" >> ${LOG_FILE}
curl -sS -XPOST ${ES_URL}/_nodes/reload_secure_settings >>${LOG_FILE} 2>&1
printf "\nCreating S3 Repository...\n" >> ${LOG_FILE}
# Have to eval the json file to use environment variable subsitution
eval "echo \"$(cat ${snapshot_repo_json_file})\"" | curl -sS -XPUT ${ES_URL}/_snapshot/sewol_s3_repository -H "Content-Type: application/json" -d @- >>${LOG_FILE} 2>&1
printf "\nCreating backup policy...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_slm/policy/sewol-auditlogs-snapshots -H "Content-Type: application/json" -d @backup-policy.json >>${LOG_FILE} 2>&1
printf "\nCreating AUDIT ILM Policy...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_ilm/policy/audit-logs-lifecycle-policy -H "Content-Type: application/json" -d @audit-logs-lifecycle-policy.json >>${LOG_FILE} 2>&1
printf "\nCreating AWE ILM Policy...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_ilm/policy/awe-logs-lifecycle-policy -H "Content-Type: application/json" -d @awe-logs-lifecycle-policy.json >>${LOG_FILE} 2>&1
printf "\nCreating AWE ALARM Index Template...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_index_template/awe_alarm_template -H "Content-Type: application/json" -d @awe-alarm-template.json >>${LOG_FILE} 2>&1
printf "\nCreating AWE WARNING Index Template...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_index_template/awe_warning_template -H "Content-Type: application/json" -d @awe-warning-template.json >>${LOG_FILE} 2>&1
printf "\nCreating AWE EVENT Index Template...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_index_template/awe_event_template -H "Content-Type: application/json" -d @awe-event-template.json >>${LOG_FILE} 2>&1
printf "\nCreating AUDIT ACTIVITY Index Template...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_index_template/audit_activity_template -H "Content-Type: application/json" -d @audit-activity-template.json >>${LOG_FILE} 2>&1
printf "\nCreating AUDIT OPSDATA Index Template...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_index_template/audit_opsdata_template -H "Content-Type: application/json" -d @audit-opsdata-template.json >>${LOG_FILE} 2>&1
printf "\nCreating AUDIT SECURITY Index Template...\n" >> ${LOG_FILE}
curl -sS -XPUT ${ES_URL}/_index_template/audit_security_template -H "Content-Type: application/json" -d @audit-security-template.json >>${LOG_FILE} 2>&1
