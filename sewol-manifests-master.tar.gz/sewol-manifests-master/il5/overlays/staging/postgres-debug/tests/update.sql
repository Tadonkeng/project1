UPDATE p1_test_ByvnS3hPTK84cDigs6dX
    SET value1='start',
        value2='finish'
    WHERE id=1;
