INSERT INTO p1_test_ByvnS3hPTK84cDigs6dX(value1,value2) VALUES ('hello', 'good-bye');
