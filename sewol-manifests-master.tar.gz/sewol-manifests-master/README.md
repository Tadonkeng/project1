# WELCOME TO YOUR NEW MANIFESTS

## Access
Your staging url is https://sewol.staging.dso.mil

## What is this?
This project is the source of truth for your application in staging/production.  It is instantiated as a bare bones guess at what your app needs to deploy.  It should serve to get your app 95% of the way there, with individual fixes needed for this specific app. 

You should see a few folders
- base : k8s resources placed here are deployed to all environments you have set, e.g. il2 staging, il4 prod, etc.
- il5 : k8s resources placed here are specific to your il5 environments but would affect both staging and prod if it were set up.
- il5/overlays/staging : k8s resources placed here only affect il5 staging.[]

* For your postgres database, these are the resources injected to mission-bootstrap project to instantiate your apps database. It will create a psql database called sewol_db with the following users and passwords loaded to the respective env variable in the container that connects to the database:
    - PGHOST
    - PGPORT
    - APP_NAME      sewol
    - PG_DATABASE   sewol_db
    - PG_USER       (Pass Var: APP_DB_ADMIN_PASSWORD)
    - PG_RW_USER    (Pass Var: APP_DB_RW_PASSWORD)
    - PG_RO_USER    (Pass Var: APP_DB_RO_PASSWORD)

## What's next?
If you haven't already, you need to make sure your application is passing the official P1 pipelines. CTF will needed for production, but you can get to staging and get an internet accessible url as long as you are passing pipeline tests. 
- With pipelines green, an infrastructure team member can add a deploy stage to the end of the pipeline to upload your release candidate image to the container registry on THIS project, and release images to the mission-bootstrap project's container registry.

The last step before deployment is to verify that pipelines can push generated images to respective container registry and that the pipeline automatically increments image tags on manifests.

At this point, if you have images built from your pipelines and your bootstrap integration & manifest repo is setup, your app should be live in staging! The default url is https://sewol.staging.dso.mil.

## How to manage
You are free to make changes to this repo. When a new change is committed, your app will automatically sync up with the changes. For more information on what is permitted, see [confluence article on permitted activites](https://confluence.il2.dso.mil/pages/viewpage.action?spaceKey=P1MDOHD&title=HowTo+-+Manifests+-+Permitted+Activities).
